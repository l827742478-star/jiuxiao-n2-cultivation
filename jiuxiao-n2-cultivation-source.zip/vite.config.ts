import { defineConfig } from 'vite'
import react from '@vitejs/plugin-react'

export default defineConfig({
  plugins: [react()],
  // Use relative asset paths so the Vite app works on a GitHub Pages project URL.
  base: './',
  server: { port: 4173, host: '127.0.0.1' },
})
