import { FormEvent, useState } from 'react'
import { KeyRound, LogIn, ShieldCheck, Sparkles, UserPlus, UserRound } from 'lucide-react'
import { loginLocalUser, registerLocalUser, type LocalUser } from './auth'

export function AuthScreen({ onAuthenticated }: { onAuthenticated: (user: LocalUser) => void }) {
  const [mode, setMode] = useState<'login' | 'register'>('login')
  const [username, setUsername] = useState('')
  const [displayName, setDisplayName] = useState('')
  const [password, setPassword] = useState('')
  const [confirmPassword, setConfirmPassword] = useState('')
  const [message, setMessage] = useState<string | null>(null)
  const [busy, setBusy] = useState(false)

  const switchMode = (next: 'login' | 'register') => {
    setMode(next)
    setMessage(null)
    setPassword('')
    setConfirmPassword('')
  }

  const submit = async (event: FormEvent<HTMLFormElement>) => {
    event.preventDefault()
    setMessage(null)
    if (mode === 'register' && password !== confirmPassword) {
      setMessage('两次输入的密码不一致')
      return
    }
    setBusy(true)
    const result = mode === 'login'
      ? await loginLocalUser(username, password)
      : await registerLocalUser(username, displayName, password)
    setBusy(false)
    if (!result.ok) {
      setMessage(result.message)
      return
    }
    onAuthenticated(result.user)
  }

  return <main className="auth-shell">
    <div className="ambient ambient-one" /><div className="ambient ambient-two" />
    <section className="auth-card">
      <div className="auth-seal"><span>九</span></div>
      <div className="eyebrow"><Sparkles size={14} />九霄宗门 · 修士身份验证</div>
      <h1>九霄日语修炼录</h1>
      <p className="auth-lead">先立修士档案，再进入 N2 渡劫之路。</p>
      <div className="auth-tabs" role="tablist" aria-label="登录或注册">
        <button type="button" className={mode === 'login' ? 'selected' : ''} onClick={() => switchMode('login')}><LogIn size={15} />登录</button>
        <button type="button" className={mode === 'register' ? 'selected' : ''} onClick={() => switchMode('register')}><UserPlus size={15} />注册</button>
      </div>
      <form className="auth-form" onSubmit={submit}>
        {mode === 'register' && <label><span>档案名</span><div className="auth-input"><UserRound size={16} /><input value={displayName} onChange={(event) => setDisplayName(event.target.value)} placeholder="例如：青云道友" autoComplete="name" /></div></label>}
        <label><span>修士账号 / 邮箱</span><div className="auth-input"><UserRound size={16} /><input value={username} onChange={(event) => setUsername(event.target.value)} placeholder="用于登录的账号" autoComplete="username" required /></div></label>
        <label><span>密码</span><div className="auth-input"><KeyRound size={16} /><input type="password" value={password} onChange={(event) => setPassword(event.target.value)} placeholder="至少 6 个字符" autoComplete={mode === 'login' ? 'current-password' : 'new-password'} required /></div></label>
        {mode === 'register' && <label><span>确认密码</span><div className="auth-input"><KeyRound size={16} /><input type="password" value={confirmPassword} onChange={(event) => setConfirmPassword(event.target.value)} placeholder="再次输入密码" autoComplete="new-password" required /></div></label>}
        {message && <p className="auth-message" role="alert">{message}</p>}
        <button className="primary-button full auth-submit" type="submit" disabled={busy}>{busy ? '正在核验...' : mode === 'login' ? <><LogIn size={16} />进入专属洞府</> : <><UserPlus size={16} />建立修士档案</>}</button>
      </form>
      <div className="auth-note"><ShieldCheck size={15} /><span>当前版本的账号与修行档案保存在本浏览器中；清除浏览器数据或更换设备不会自动同步。</span></div>
    </section>
  </main>
}

