import { useEffect, useMemo, useRef, useState } from 'react'
import { BookOpen, Brain, ChevronRight, CircleHelp, Flame, Gem, Home, Import, Library, LogOut, Menu, Moon, Search, Settings2, Sparkles, Swords, Target, Trophy, Upload, X, Zap } from 'lucide-react'
import { coverage, grammar, quests, realms, readings, vocab } from './data'
import { importedStats } from './importedKnowledge'
import { collocations, honorifics, supplementalKnowledge, transitivity, wordClasses } from './supplementalKnowledge'
import { AuthScreen } from './AuthScreen'
import { clearSession, getCurrentUser, readUserProfile, saveUserProfile, type LocalUser } from './auth'
import type { Knowledge, KnowledgeKind, Mastery, Reading, UserState } from './types'

type Tab = 'home' | 'vocab' | 'grammar' | 'reading' | 'curriculum' | 'mistakes' | 'exam' | 'index'
type Quiz = { item: Knowledge | Reading; prompt: string; options: string[]; answer: number; explanation: string }

const today = () => new Date().toISOString().slice(0, 10)

const initialState: UserState = {
  xp: 135,
  stones: 42,
  streak: 3,
  lastActive: today(),
  completedQuestIds: [],
  masteredIds: [],
  heartDemonIds: [],
  attempts: 17,
  correct: 13,
  meditationMinutes: 185,
  title: '词海采气者',
}

function App() {
  const [tab, setTab] = useState<Tab>('home')
  const [currentUser, setCurrentUser] = useState<LocalUser | null>(() => getCurrentUser())
  const [state, setState] = useState<UserState>(() => {
    const user = getCurrentUser()
    return user ? readUserProfile(user.id, initialState) : { ...initialState, masteredIds: [], heartDemonIds: [], completedQuestIds: [] }
  })
  const [mobileNav, setMobileNav] = useState(false)
  const [toast, setToast] = useState<string | null>(null)
  const [showImport, setShowImport] = useState(false)
  const [showSettings, setShowSettings] = useState(false)

  useEffect(() => {
    if (currentUser) saveUserProfile(currentUser.id, state)
  }, [currentUser, state])
  useEffect(() => {
    if (!toast) return
    const id = window.setTimeout(() => setToast(null), 2600)
    return () => window.clearTimeout(id)
  }, [toast])

  if (!currentUser) return <AuthScreen onAuthenticated={(user) => {
    setState(readUserProfile(user.id, initialState))
    setCurrentUser(user)
    setTab('home')
  }} />

  const realmIndex = Math.max(0, realms.findIndex((r, i) => state.xp >= r.minXp && (realms[i + 1] == null || state.xp < realms[i + 1].minXp)))
  const realm = realms[realmIndex]
  const nextRealm = realms[realmIndex + 1]
  const realmProgress = nextRealm ? Math.min(100, ((state.xp - realm.minXp) / (nextRealm.minXp - realm.minXp)) * 100) : 100

  const addReward = (xp: number, stones = 0, message = `获得 ${xp} 点修为`) => {
    setState((s) => ({ ...s, xp: s.xp + xp, stones: s.stones + stones, meditationMinutes: s.meditationMinutes + 5 }))
    setToast(message + (stones ? `，灵石 +${stones}` : ''))
  }

  const markKnowledge = (item: Knowledge, correct: boolean) => {
    setState((s) => {
      const masteredIds = correct && !s.masteredIds.includes(item.id) ? [...s.masteredIds, item.id] : s.masteredIds
      const heartDemonIds = !correct && !s.heartDemonIds.includes(item.id) ? [...s.heartDemonIds, item.id] : s.heartDemonIds
      return { ...s, masteredIds, heartDemonIds, attempts: s.attempts + 1, correct: s.correct + (correct ? 1 : 0) }
    })
    addReward(correct ? item.xp : 1, correct ? 0 : 0, correct ? '破阵成功，知识已入识海' : '心魔现形，已收入心魔炉')
  }

  const completeQuest = (id: string) => {
    const quest = quests.find((q) => q.id === id)
    if (!quest || state.completedQuestIds.includes(id)) return
    setState((s) => ({ ...s, completedQuestIds: [...s.completedQuestIds, id] }))
    addReward(quest.rewardXp, quest.rewardStones, `宗门任务「${quest.title}」完成`)
  }

  const resetState = () => {
    setState(initialState)
    setToast('修行日志已重置')
  }

  const exportState = () => {
    const blob = new Blob([JSON.stringify({ state, exportedAt: new Date().toISOString() }, null, 2)], { type: 'application/json' })
    const url = URL.createObjectURL(blob)
    const a = document.createElement('a')
    a.href = url
    a.download = '九霄日语修炼录-修行日志.json'
    a.click()
    URL.revokeObjectURL(url)
    setToast('修行日志已导出')
  }

  const importState = (payload: string) => {
    try {
      const parsed = JSON.parse(payload)
      const next = parsed.state ?? parsed
      if (typeof next.xp !== 'number' || !Array.isArray(next.masteredIds)) throw new Error('invalid')
      setState({ ...initialState, ...next })
      setShowImport(false)
      setToast('修行日志已导入')
    } catch {
      setToast('导入失败：这不是有效的修行日志')
    }
  }

  const nav = (next: Tab) => { setTab(next); setMobileNav(false) }

  return (
    <div className="app-shell">
      <div className="ambient ambient-one" /><div className="ambient ambient-two" />
      <header className="topbar">
        <button className="mobile-menu" onClick={() => setMobileNav((v) => !v)} aria-label="打开宗门菜单"><Menu size={20} /></button>
        <div className="brand-mark"><span>九</span></div>
        <div className="brand-copy"><strong>九霄日语修炼录</strong><span>N2渡劫篇</span></div>
        <div className="top-actions">
          <div className="streak"><Flame size={16} /><span>道心 {state.streak} 日</span></div>
          <div className="stone-pill"><Gem size={15} /><span>{state.stones}</span></div>
          <button className="profile-pill" onClick={() => setShowSettings(true)} aria-label="打开我的修士档案"><span className="profile-avatar">{currentUser.displayName.slice(0, 1)}</span><span className="profile-copy"><strong>{currentUser.displayName}</strong><small>@{currentUser.username}</small></span></button>
          <button className="icon-button" onClick={() => setShowSettings(true)} aria-label="修炼台设置"><Settings2 size={18} /></button>
        </div>
      </header>

      <div className="workspace">
        <aside className={`sidebar ${mobileNav ? 'open' : ''}`}>
          <div className="sect-label">宗门修炼台</div>
          <NavButton icon={<Home size={18} />} label="洞府总览" active={tab === 'home'} onClick={() => nav('home')} />
          <NavButton icon={<Sparkles size={18} />} label="词海纳气" active={tab === 'vocab'} onClick={() => nav('vocab')} count={vocab.length} />
          <NavButton icon={<Zap size={18} />} label="法诀参悟" active={tab === 'grammar'} onClick={() => nav('grammar')} count={grammar.length} />
          <NavButton icon={<BookOpen size={18} />} label="典籍秘境" active={tab === 'reading'} onClick={() => nav('reading')} count={readings.length} />
          <NavButton icon={<Target size={18} />} label="N2百艺" active={tab === 'curriculum'} onClick={() => nav('curriculum')} count={supplementalKnowledge.length} />
          <div className="nav-divider" />
          <NavButton icon={<Flame size={18} />} label="心魔炉" active={tab === 'mistakes'} onClick={() => nav('mistakes')} badge={state.heartDemonIds.length || undefined} />
          <NavButton icon={<Swords size={18} />} label="问心渡劫" active={tab === 'exam'} onClick={() => nav('exam')} />
          <NavButton icon={<Library size={18} />} label="天机索引" active={tab === 'index'} onClick={() => nav('index')} />
          <div className="sidebar-bottom"><div className="mini-realm"><span className="realm-seal" style={{ color: realm.tone, borderColor: `${realm.tone}66` }}>{realm.seal}</span><div><small>当前境界</small><strong>{realm.name}</strong></div></div><div className="side-xp"><span>修为</span><strong>{state.xp.toLocaleString()}</strong></div></div>
        </aside>

        <main className="main-content">
          {tab === 'home' && <HomePage state={state} realm={realm} nextRealm={nextRealm} realmProgress={realmProgress} onTab={nav} onQuest={completeQuest} />}
          {tab === 'vocab' && <KnowledgePage title="词海纳气" subtitle="将高频词汇炼成可调用的灵力" kind="vocab" items={vocab} onAnswer={markKnowledge} />}
          {tab === 'grammar' && <KnowledgePage title="法诀参悟" subtitle="在接续、语气与语境中找到破阵之解" kind="grammar" items={grammar} onAnswer={markKnowledge} />}
          {tab === 'reading' && <ReadingPage readings={readings} onAnswer={markKnowledge} />}
          {tab === 'curriculum' && <CurriculumPage onAnswer={markKnowledge} />}
          {tab === 'mistakes' && <MistakePage items={[...vocab, ...grammar, ...supplementalKnowledge]} state={state} onTab={() => nav('curriculum')} />}
          {tab === 'exam' && <ExamPage items={[...vocab.slice(0, 6), ...grammar.slice(0, 6), ...supplementalKnowledge.slice(0, 6), ...readings]} onAnswer={markKnowledge} onReward={addReward} />}
          {tab === 'index' && <IndexPage />}
        </main>
      </div>

      {toast && <div className="toast"><Sparkles size={16} />{toast}</div>}
      {showSettings && <SettingsModal currentUser={currentUser} onClose={() => setShowSettings(false)} onExport={exportState} onImport={() => { setShowSettings(false); setShowImport(true) }} onReset={resetState} onLogout={() => { saveUserProfile(currentUser.id, state); clearSession(); setShowSettings(false); setCurrentUser(null) }} />}
      {showImport && <ImportModal onClose={() => setShowImport(false)} onImport={importState} />}
    </div>
  )
}

function NavButton({ icon, label, count, badge, active, onClick }: { icon: React.ReactNode; label: string; count?: number; badge?: number; active: boolean; onClick: () => void }) {
  return <button className={`nav-button ${active ? 'active' : ''}`} onClick={onClick}>{icon}<span>{label}</span>{badge ? <em className="nav-badge">{badge}</em> : count ? <small>{count}</small> : null}</button>
}

function HomePage({ state, realm, nextRealm, realmProgress, onTab, onQuest }: { state: UserState; realm: typeof realms[number]; nextRealm?: typeof realms[number]; realmProgress: number; onTab: (tab: Tab) => void; onQuest: (id: string) => void }) {
  const completion = Math.round((state.correct / Math.max(1, state.attempts)) * 100)
  return <>
    <div className="page-heading home-heading"><div><div className="eyebrow"><Sparkles size={14} />东瀛语言界 · 第三百六十七日</div><h1>今日，继续你的<span>渡劫之路</span></h1><p>道友，识海中的法诀正在等待下一次闭关。</p></div><button className="primary-button" onClick={() => onTab('vocab')}><Zap size={17} />开始今日修炼 <ChevronRight size={16} /></button></div>
    <div className="hero-grid">
      <section className="realm-card"><div className="card-glow" /><div className="realm-card-top"><div><span className="card-kicker">当前境界</span><h2>{realm.name}</h2><p>{realm.unlock}</p></div><div className="large-seal" style={{ color: realm.tone, borderColor: `${realm.tone}66` }}>{realm.seal}</div></div><div className="realm-progress"><div className="progress-label"><span>修为进度</span><strong>{state.xp.toLocaleString()} <i>/ {nextRealm?.minXp.toLocaleString() ?? '∞'}</i></strong></div><div className="progress-track"><div className="progress-fill" style={{ width: `${realmProgress}%`, background: realm.tone }} /></div><div className="next-realm"><span>{realm.name}</span>{nextRealm ? <><span className="dots" /><span>{nextRealm.name} · 还需 {nextRealm.minXp - state.xp} 修为</span></> : <span>已至飞升</span>}</div></div><div className="realm-stats"><div><small>道心连胜</small><strong>{state.streak}<em>日</em></strong></div><div><small>修行时长</small><strong>{Math.floor(state.meditationMinutes / 60)}<em>h</em> {state.meditationMinutes % 60}<em>m</em></strong></div><div><small>问心准确</small><strong>{completion}<em>%</em></strong></div></div></section>
      <section className="daily-card"><div className="section-heading"><div><span className="card-kicker">宗门召令</span><h3>今日修炼</h3></div><span className="date-chip">10月14日 · 周三</span></div><div className="quest-list">{quests.map((q) => <button key={q.id} className={`quest-row ${state.completedQuestIds.includes(q.id) ? 'done' : ''}`} onClick={() => onQuest(q.id)}><span className="quest-icon">{q.targetKind === 'vocab' ? <Sparkles size={15} /> : q.targetKind === 'grammar' ? <Zap size={15} /> : <BookOpen size={15} />}</span><span className="quest-copy"><strong>{q.title}</strong><small>{state.completedQuestIds.includes(q.id) ? '已完成 · 修为已入体' : q.body}</small></span><span className="quest-reward">+{q.rewardXp}<small>修为</small></span><ChevronRight size={15} /></button>)}</div><button className="ghost-button full" onClick={() => onTab('index')}>查看完整宗门任务 <ChevronRight size={15} /></button></section>
    </div>
    <div className="section-heading spaced"><div><span className="card-kicker">天机观测</span><h3>识海进度</h3></div><button className="text-button" onClick={() => onTab('index')}>查看全部 <ChevronRight size={15} /></button></div>
    <div className="coverage-grid">{coverage.slice(0, 4).map((c) => <CoverageCard key={c.name} {...c} />)}</div>
    <div className="lower-grid"><section className="activity-card"><div className="section-heading"><div><span className="card-kicker">修行日志</span><h3>最近的悟道</h3></div><button className="text-button" onClick={() => onTab('mistakes')}>进入心魔炉 <ChevronRight size={15} /></button></div><div className="activity-list"><Activity icon={<Sparkles size={16} />} tone="gold" title="词海纳气 · 一次闭关" detail="掌握了「著しい」与「該当する」" time="刚刚" /><Activity icon={<Zap size={16} />} tone="purple" title="法诀参悟 · 破阵成功" detail="参悟「～わけではない」" time="昨天" /><Activity icon={<BookOpen size={16} />} tone="blue" title="典籍秘境 · 完成一卷" detail="公告类阅读，正确率 100%" time="2天前" /></div></section><section className="title-card"><div className="title-orbit"><Trophy size={24} /></div><span className="card-kicker">当前称号</span><h3>{state.title}</h3><p>再完成一轮典籍试炼，即可解锁「阅读破阵师」。</p><div className="mini-meter"><span style={{ width: '68%' }} /></div><small>称号进阶 · 68%</small></section></div>
  </>
}

function CoverageCard({ name, current, target, tone }: { name: string; current: number; target: number; tone: string }) {
  const percent = Math.min(100, Math.round((current / target) * 100))
  return <div className={`coverage-card ${tone}`}><div className="coverage-top"><span>{name}</span><strong>{current}<i>/{target}</i></strong></div><div className="mini-meter"><span style={{ width: `${Math.max(2, percent)}%` }} /></div><small>{percent}% 已入库 · 批次一</small></div>
}

function Activity({ icon, tone, title, detail, time }: { icon: React.ReactNode; tone: string; title: string; detail: string; time: string }) {
  return <div className="activity-row"><span className={`activity-icon ${tone}`}>{icon}</span><span><strong>{title}</strong><small>{detail}</small></span><time>{time}</time></div>
}

type CurriculumKind = 'honorific' | 'collocation' | 'wordClass' | 'transitivity'

const curriculumSections: Record<CurriculumKind, { title: string; subtitle: string; items: Knowledge[] }> = {
  honorific: { title: '礼法与正式表达', subtitle: '把尊敬语、谦让语和郑重请求炼成可直接调用的礼法。', items: honorifics },
  collocation: { title: '合璧术与惯用搭配', subtitle: '按整体搭配记忆助词与动词，避免逐字翻译造成误判。', items: collocations },
  wordClass: { title: '词类与活用辨析', subtitle: '从修饰对象、活用形式和接续判断词语在句中的真实职能。', items: wordClasses },
  transitivity: { title: '自动词·他动词', subtitle: '用「が／を」和状态变化方向辨认成对动词。', items: transitivity },
}

function CurriculumPage({ onAnswer }: { onAnswer: (item: Knowledge, correct: boolean) => void }) {
  const [kind, setKind] = useState<CurriculumKind>('honorific')
  const section = curriculumSections[kind]
  return <>
    <div className="page-heading"><div><div className="eyebrow"><Target size={14} />N2百艺 · 独立卷宗</div><h1>四卷补全修炼</h1><p>600 条不重复的专项卡片，覆盖礼法、搭配、词类活用和自动词·他动词。</p></div><div className="index-stamp">600 条</div></div>
    <div className="filter-pills category-tabs">{(Object.keys(curriculumSections) as CurriculumKind[]).map((key) => <button key={key} className={kind === key ? 'selected' : ''} onClick={() => setKind(key)}>{curriculumSections[key].title}</button>)}</div>
    <KnowledgePage key={kind} title={section.title} subtitle={section.subtitle} kind={kind} items={section.items} onAnswer={onAnswer} showHeading={false} />
  </>
}

function KnowledgePage({ title, subtitle, kind, items, onAnswer, showHeading = true }: { title: string; subtitle: string; kind: KnowledgeKind; items: Knowledge[]; onAnswer: (item: Knowledge, correct: boolean) => void; showHeading?: boolean }) {
  const [search, setSearch] = useState('')
  const [level, setLevel] = useState<'全部' | Knowledge['level']>('全部')
  const [page, setPage] = useState(1)
  const [active, setActive] = useState<Knowledge | null>(null)
  const [quiz, setQuiz] = useState<Quiz | null>(null)
  const filtered = useMemo(() => items.filter((i) => (level === '全部' || i.level === level) && `${i.title}${i.reading ?? ''}${i.meaning}${i.detail}${i.tags.join('')}${i.sourceFields?.map((field) => `${field.label}${field.value}`).join('') ?? ''}`.toLowerCase().includes(search.toLowerCase())), [items, level, search])
  const pageSize = 40
  const pageCount = Math.max(1, Math.ceil(filtered.length / pageSize))
  const visible = filtered.slice((page - 1) * pageSize, page * pageSize)
  useEffect(() => setPage(1), [search, level])
  useEffect(() => setPage((current) => Math.min(current, pageCount)), [pageCount])
  const startQuiz = (item: Knowledge) => {
    const distractors = [...new Set(items.filter((i) => i.id !== item.id).map((i) => i.meaning).filter((meaning) => meaning !== item.meaning))].slice(0, 3)
    const options = [item.meaning, ...distractors].sort(() => Math.random() - 0.5)
    setQuiz({ item, prompt: kind === 'grammar' ? `请选择「${item.title}」的正确含义` : `请选择「${item.title}」的中文释义`, options, answer: options.indexOf(item.meaning), explanation: `${item.title}：${item.detail}` })
  }
  const answer = (index: number) => { if (!quiz) return; onAnswer(quiz.item as Knowledge, index === quiz.answer); setQuiz(null) }
  const kindLabel: Record<KnowledgeKind, string> = { vocab: '词海', kanji: '汉字', grammar: '法诀', reading: '典籍', honorific: '礼法', collocation: '搭配', wordClass: '词类', transitivity: '动词辨析' }
  return <>
    {showHeading && <div className="page-heading"><div><div className="eyebrow"><Sparkles size={14} />修炼模块 · {kindLabel[kind]}</div><h1>{title}</h1><p>{subtitle}</p></div><button className="primary-button" onClick={() => filtered[0] && startQuiz(filtered[0])}><Brain size={17} />开启问心阵</button></div>}
    <div className="module-stats"><Stat icon={<Library size={17} />} label="识海总数" value={items.length.toString()} /><Stat icon={<Sparkles size={17} />} label="今日闭关" value="12" /><Stat icon={<Flame size={17} />} label="心魔缠身" value="4" /><Stat icon={<Target size={17} />} label="本轮准确" value="76%" /></div>
    <div className="toolbar"><div className="search-box"><Search size={17} /><input value={search} onChange={(e) => setSearch(e.target.value)} placeholder="搜寻词义、法诀……" /></div><div className="filter-pills">{(['全部', '基础复现', 'N2核心', 'N2扩展'] as const).map((v) => <button key={v} className={level === v ? 'selected' : ''} onClick={() => setLevel(v)}>{v}</button>)}</div></div>
    <div className="knowledge-layout"><section><div className="knowledge-list">{visible.map((item) => <KnowledgeRow key={item.id} item={item} onOpen={() => setActive(item)} onQuiz={() => startQuiz(item)} />)}{filtered.length === 0 && <EmptyState text="识海中暂未找到对应内容" />}</div>{filtered.length > 0 && <div className="pagination"><span>第 {page} / {pageCount} 页 · 共 {filtered.length} 条</span><div><button disabled={page === 1} onClick={() => setPage((current) => Math.max(1, current - 1))}>上一页</button><button disabled={page === pageCount} onClick={() => setPage((current) => Math.min(pageCount, current + 1))}>下一页</button></div></div>}</section><aside className="module-aside"><div className="aside-card"><span className="card-kicker">修炼提示</span><h3>先识其形，再悟其用</h3><p>不要只记住中文。先朗读日语，再观察它在句中的位置和语气。附卷卡片的原始字段会保留在悟道详情里。</p><div className="tip-line"><CircleHelp size={16} />每次问心后都查看悟道批注</div></div><div className="aside-card dark"><span className="card-kicker">今日闭关</span><strong>还需修炼 8 枚灵符</strong><div className="mini-meter"><span style={{ width: '42%' }} /></div><small>4 / 12 完成</small></div></aside></div>
    {active && <KnowledgeModal item={active} onClose={() => setActive(null)} onQuiz={() => { setActive(null); startQuiz(active) }} />}
    {quiz && <QuizModal quiz={quiz} onAnswer={answer} onClose={() => setQuiz(null)} />}
  </>
}

function KnowledgeRow({ item, onOpen, onQuiz }: { item: Knowledge; onOpen: () => void; onQuiz: () => void }) {
  const icon = item.kind === 'vocab' ? '詞' : item.kind === 'honorific' ? '礼' : item.kind === 'collocation' ? '搭' : item.kind === 'wordClass' ? '类' : item.kind === 'transitivity' ? '动' : '法'
  return <div className="knowledge-row"><button className={`knowledge-glyph ${item.kind}`} onClick={onOpen}>{icon}</button><button className="knowledge-main" onClick={onOpen}><span className="knowledge-title"><strong>{item.title}</strong>{item.reading && <small>{item.reading}</small>}</span><span className="knowledge-meaning">{item.meaning}</span><span className="tag-line">{item.tags.slice(0, 3).map((t) => <em key={t}>{t}</em>)}</span></button><span className={`mastery ${item.mastery === '已悟' ? 'done' : ''}`}>{item.mastery}</span><button className="round-action" onClick={onQuiz} aria-label="开启问心阵"><ChevronRight size={17} /></button></div>
}

function ReadingPage({ readings: items, onAnswer }: { readings: Reading[]; onAnswer: (item: Knowledge, correct: boolean) => void }) {
  const [active, setActive] = useState<Reading | null>(null)
  const [answers, setAnswers] = useState<Record<string, number>>({})
  const [submitted, setSubmitted] = useState(false)
  const open = (item: Reading) => { setActive(item); setAnswers({}); setSubmitted(false) }
  const submit = () => { if (!active) return; const correct = active.questions.filter((q, i) => answers[`${active.id}-${i}`] === q.answer).length; onAnswer(active, correct === active.questions.length); setSubmitted(true) }
  return <><div className="page-heading"><div><div className="eyebrow"><BookOpen size={14} />典籍秘境 · 阅读破阵</div><h1>典籍试炼</h1><p>从公告、说明文到议论文，追踪作者的阵眼与逻辑脉络。</p></div><div className="reading-count"><strong>{items.length}</strong><span>卷典籍已入库</span></div></div><div className="reading-hero"><div><span className="card-kicker">今日秘境</span><h2>把每一段文字，读成一张地图</h2><p>先看问题，再回到原文定位；注意转折、因果、范围和否定。</p></div><div className="reading-symbol"><BookOpen size={36} /></div></div><div className="reading-grid">{items.map((item) => <button key={item.id} className="reading-card" onClick={() => open(item)}><div className="reading-card-top"><span className={`level-dot ${item.level === 'N2扩展' ? 'hot' : ''}`} />{item.level}<span className="reading-time">{item.suggestedMinutes} min</span></div><h3>{item.title}</h3><p>{item.detail}</p><div className="tag-line">{item.tags.map((t) => <em key={t}>{t}</em>)}</div><span className="read-more">进入秘境 <ChevronRight size={15} /></span></button>)}</div>{active && <ReadingModal item={active} answers={answers} setAnswers={setAnswers} submitted={submitted} onClose={() => setActive(null)} onSubmit={submit} />}</>
}

function MistakePage({ items, state, onTab }: { items: Knowledge[]; state: UserState; onTab: () => void }) {
  const demons = items.filter((i) => state.heartDemonIds.includes(i.id))
  return <><div className="page-heading"><div><div className="eyebrow"><Flame size={14} />心魔炉 · 闭关复盘</div><h1>斩除心魔</h1><p>错误不是损耗，而是识海告诉你的下一处突破口。</p></div><button className="primary-button" onClick={onTab}><Brain size={17} />去N2百艺</button></div><div className="demon-banner"><div className="demon-flame"><Flame size={29} /></div><div><span className="card-kicker">当前心魔</span><h2>{demons.length || 0} <small>枚待斩除</small></h2><p>每一次复盘都会削弱它的根基。</p></div><div className="demon-meter"><span>本周斩魔进度</span><strong>{Math.min(100, demons.length * 12)}%</strong><div className="progress-track"><div className="progress-fill red" style={{ width: `${Math.min(100, demons.length * 12)}%` }} /></div></div></div><div className="section-heading spaced"><div><span className="card-kicker">心魔清单</span><h3>需要再次闭关的知识</h3></div></div><div className="knowledge-list demon-list">{demons.length ? demons.map((item) => <KnowledgeRow key={item.id} item={item} onOpen={() => undefined} onQuiz={() => undefined} />) : <EmptyState text="今日识海清明，暂未发现待斩心魔" />}</div></>
}

function ExamPage({ items, onAnswer, onReward }: { items: (Knowledge | Reading)[]; onAnswer: (item: Knowledge, correct: boolean) => void; onReward: (xp: number, stones?: number, message?: string) => void }) {
  const [started, setStarted] = useState(false)
  const [index, setIndex] = useState(0)
  const [score, setScore] = useState(0)
  const [done, setDone] = useState(false)
  const quiz = useMemo<Quiz>(() => makeQuiz(items[index % items.length]), [items, index])
  const answer = (i: number) => { const ok = i === quiz.answer; onAnswer(quiz.item as Knowledge, ok); if (ok) setScore((s) => s + 1); if (index >= 4) { setDone(true); onReward(100, 20, `问心渡劫完成 · ${ok ? score + 1 : score}/5`); } else setIndex((v) => v + 1) }
  return <><div className="page-heading"><div><div className="eyebrow"><Swords size={14} />问心渡劫 · 综合试炼</div><h1>渡劫台</h1><p>五道阵眼，检验词海、法诀与阅读的综合调用能力。</p></div><div className="exam-badge"><span>本次天劫</span><strong>5</strong><small>阵眼</small></div></div>{!started ? <div className="exam-start"><div className="exam-orbit"><Swords size={42} /></div><span className="card-kicker">N2综合渡劫 · 第一卷</span><h2>你的识海，准备好了吗？</h2><p>本次试炼共五道阵眼，包含词义、语法和典籍理解。每次选择后会立即记录悟道或心魔。</p><div className="exam-rules"><span><Zap size={16} />每题答对 +2 修为</span><span><Flame size={16} />答错收入心魔炉</span><span><Target size={16} />完成后获得灵石</span></div><button className="primary-button large" onClick={() => setStarted(true)}>开启天劫 <ChevronRight size={17} /></button></div> : done ? <div className="exam-result"><div className="result-seal"><Trophy size={38} /></div><span className="card-kicker">天劫已落</span><h2>{score >= 3 ? '破劫成功' : '心魔未尽'}</h2><strong>{score}<small> / 5</small></strong><p>{score >= 3 ? '你的基础识海已经稳固，继续清理薄弱法诀。' : '不要急着冲境，先回到心魔炉，逐个斩除错因。'}</p><button className="ghost-button" onClick={() => { setStarted(false); setDone(false); setIndex(0); setScore(0) }}>再战一轮</button></div> : <div className="exam-quiz-wrap"><div className="exam-progress"><span>第 {index + 1} / 5 道阵眼</span><div className="progress-track"><div className="progress-fill gold" style={{ width: `${(index / 5) * 100}%` }} /></div></div><QuizModal quiz={quiz} onAnswer={answer} embedded /></div>}</>
}

function IndexPage() {
  const rows = coverage
  return <><div className="page-heading"><div><div className="eyebrow"><Library size={14} />天机索引 · 内容进度</div><h1>N2知识总索引</h1><p>三卷附加典籍已并入词海、法诀和典籍秘境，所有卡片都可搜索、查看原始批注并进入问心阵。</p></div><div className="index-stamp">附卷并入</div></div><div className="index-grid">{rows.map((row) => <CoverageCard key={row.name} {...row} />)}</div><section className="roadmap-card"><div className="section-heading"><div><span className="card-kicker">附卷分流</span><h3>每一卷资料如何进入修炼</h3></div></div><div className="import-route-grid">{importedStats.sourceRows.map((source) => <div className="import-route" key={source.sourceName}><span className="route-seal">{source.sourceName.includes('阅读') ? '典' : source.sourceName.includes('表达') ? '诀' : '词'}</span><div><strong>{source.sourceName}</strong><small>{source.rows.toLocaleString()} 条 · 已接入对应模块</small></div></div>)}</div></section><section className="roadmap-card"><div className="section-heading"><div><span className="card-kicker">境界路线</span><h3>从炼气到飞升</h3></div></div><div className="roadmap">{realms.slice(0, 6).map((r, i) => <div key={r.name} className={`roadmap-step ${i === 1 ? 'current' : ''}`}><span style={{ color: r.tone, borderColor: `${r.tone}66` }}>{r.seal}</span><div><strong>{r.name}</strong><small>{r.unlock}</small></div></div>)}</div></section></>
}

function Stat({ icon, label, value }: { icon: React.ReactNode; label: string; value: string }) { return <div className="stat-card"><span>{icon}</span><div><small>{label}</small><strong>{value}</strong></div></div> }
function EmptyState({ text }: { text: string }) { return <div className="empty-state"><Moon size={23} /><span>{text}</span></div> }

function KnowledgeModal({ item, onClose, onQuiz }: { item: Knowledge; onClose: () => void; onQuiz: () => void }) { useEffect(() => { const closeOnEscape = (event: KeyboardEvent) => { if (event.key === 'Escape') onClose() }; window.addEventListener('keydown', closeOnEscape); return () => window.removeEventListener('keydown', closeOnEscape) }, [onClose]); const kindLabel: Record<KnowledgeKind, string> = { vocab: '词海', kanji: '汉字', grammar: '法诀', reading: '典籍', honorific: '礼法', collocation: '搭配', wordClass: '词类', transitivity: '动词辨析' }; return <div className="modal-backdrop" onClick={onClose}><div className="knowledge-modal" onClick={(e) => e.stopPropagation()}><button className="close-button" onClick={onClose}><X size={18} /></button><span className="card-kicker">{item.level} · {kindLabel[item.kind]}</span><h2>{item.title}</h2>{item.reading && <div className="modal-reading">{item.reading}</div>}<div className="modal-meaning">{item.meaning}</div><p>{item.detail}</p>{item.example && <div className="example-box"><span>悟道例句</span><strong>{item.example}</strong><p>{item.exampleZh}</p></div>}<div className="tag-line">{item.tags.map((t) => <em key={t}>{t}</em>)}</div>{item.sourceFields?.length ? <div className="source-facts"><span className="card-kicker">附卷原始批注 · {item.sourceName} · 第 {item.sourceRow} 条</span><div className="source-fact-grid">{item.sourceFields.map((field) => <div className="source-fact" key={`${field.label}-${field.value}`}><small>{field.label}</small><p>{field.value}</p></div>)}</div></div> : null}<button className="primary-button full" onClick={onQuiz}><Brain size={17} />开启问心阵</button></div></div> }

function QuizModal({ quiz, onAnswer, onClose, embedded = false }: { quiz: Quiz; onAnswer: (index: number) => void; onClose?: () => void; embedded?: boolean }) { return <div className={embedded ? 'quiz-card embedded' : 'modal-backdrop'} onClick={embedded ? undefined : onClose}><div className={embedded ? 'quiz-card-inner' : 'quiz-card-inner modal-quiz'} onClick={(e) => e.stopPropagation()}>{!embedded && <button className="close-button" onClick={onClose}><X size={18} /></button>}<span className="card-kicker">问心阵 · 请选择破阵之解</span><h2>{quiz.prompt}</h2><div className="answer-grid">{quiz.options.map((option, i) => <button key={option} onClick={() => onAnswer(i)}><span>{String.fromCharCode(65 + i)}</span>{option}</button>)}</div><div className="quiz-tip"><CircleHelp size={15} />完成后会记录修为；若答错，心魔将进入心魔炉。</div></div></div> }

function ReadingModal({ item, answers, setAnswers, submitted, onClose, onSubmit }: { item: Reading; answers: Record<string, number>; setAnswers: React.Dispatch<React.SetStateAction<Record<string, number>>>; submitted: boolean; onClose: () => void; onSubmit: () => void }) { useEffect(() => { const closeOnEscape = (event: KeyboardEvent) => { if (event.key === 'Escape') onClose() }; window.addEventListener('keydown', closeOnEscape); return () => window.removeEventListener('keydown', closeOnEscape) }, [onClose]); return <div className="modal-backdrop" onClick={onClose}><div className="reading-modal" onClick={(e) => e.stopPropagation()}><button className="close-button" onClick={onClose}><X size={18} /></button><span className="card-kicker">典籍秘境 · {item.level}{item.sourceLevel ? ` · ${item.sourceLevel}` : ''}</span><h2>{item.title}</h2><div className="reading-body">{item.body}</div>{item.translation && <div className="translation-box"><span>译文卷注</span><p>{item.translation}</p></div>}{item.readingNotes && <div className="reading-notes"><span>解题思路</span><p>{item.readingNotes}</p></div>}<div className="reading-questions">{item.questions.map((q, qi) => <div className="reading-question" key={q.prompt}><strong>{qi + 1}. {q.prompt}</strong><div className="reading-options">{q.options.map((o, oi) => <label key={o} className={submitted ? oi === q.answer ? 'correct' : answers[`${item.id}-${qi}`] === oi ? 'wrong' : '' : ''}><input type="radio" name={`${item.id}-${qi}`} checked={answers[`${item.id}-${qi}`] === oi} onChange={() => setAnswers((a) => ({ ...a, [`${item.id}-${qi}`]: oi }))} disabled={submitted} />{o}</label>)}</div>{submitted && <p className="explanation">悟道批注：{q.explanation}</p>}</div>)}</div>{item.sourceFields?.length ? <div className="source-facts reading-source"><span className="card-kicker">附卷原始批注 · 第 {item.sourceRow} 条</span><div className="source-fact-grid">{item.sourceFields.map((field) => <div className="source-fact" key={`${field.label}-${field.value}`}><small>{field.label}</small><p>{field.value}</p></div>)}</div></div> : null}{!submitted ? <button className="primary-button full" onClick={onSubmit}>提交破阵结果 <ChevronRight size={16} /></button> : <button className="ghost-button full" onClick={onClose}>收起典籍</button>}</div></div> }

function SettingsModal({ currentUser, onClose, onExport, onImport, onReset, onLogout }: { currentUser: LocalUser; onClose: () => void; onExport: () => void; onImport: () => void; onReset: () => void; onLogout: () => void }) { return <div className="modal-backdrop" onClick={onClose}><div className="settings-modal" onClick={(e) => e.stopPropagation()}><button className="close-button" onClick={onClose}><X size={18} /></button><span className="card-kicker">修炼台设置 · 专属档案</span><h2>我的修士档案</h2><div className="profile-panel"><span className="profile-avatar large">{currentUser.displayName.slice(0, 1)}</span><div><strong>{currentUser.displayName}</strong><small>@{currentUser.username}</small><small>入宗日期 · {new Date(currentUser.createdAt).toLocaleDateString('zh-CN')}</small></div></div><p>这个档案只记录当前账号的修为、道心、心魔、任务和学习进度。退出后，下一位修士会进入自己的独立识海。</p><div className="settings-actions"><button className="ghost-button" onClick={onExport}><Upload size={16} />导出我的修行日志</button><button className="ghost-button" onClick={onImport}><Import size={16} />导入我的修行日志</button><button className="danger-button" onClick={onReset}>重置我的修行记录</button><button className="ghost-button logout-button" onClick={onLogout}><LogOut size={16} />退出当前账号</button></div></div></div> }

function ImportModal({ onClose, onImport }: { onClose: () => void; onImport: (payload: string) => void }) { const ref = useRef<HTMLInputElement>(null); return <div className="modal-backdrop" onClick={onClose}><div className="settings-modal" onClick={(e) => e.stopPropagation()}><button className="close-button" onClick={onClose}><X size={18} /></button><span className="card-kicker">归还修行日志</span><h2>导入本地档案</h2><p>请选择此前导出的JSON修行日志。</p><input ref={ref} type="file" accept="application/json" hidden onChange={(e) => { const file = e.target.files?.[0]; if (!file) return; const reader = new FileReader(); reader.onload = () => onImport(String(reader.result)); reader.readAsText(file) }} /><button className="primary-button full" onClick={() => ref.current?.click()}><Upload size={16} />选择JSON档案</button></div></div> }

function makeQuiz(item: Knowledge | Reading): Quiz {
  if ('questions' in item) return { item, prompt: item.questions[0].prompt, options: item.questions[0].options, answer: item.questions[0].answer, explanation: item.questions[0].explanation }
  const pool = [...vocab, ...grammar, ...supplementalKnowledge].filter((x) => x.id !== item.id)
  const distractors = [...new Set(pool.map((x) => x.meaning).filter((meaning) => meaning !== item.meaning))].slice(0, 3)
  const options = [item.meaning, ...distractors].sort(() => Math.random() - 0.5)
  return { item, prompt: `请选择「${item.title}」的正确释义`, options, answer: options.indexOf(item.meaning), explanation: item.detail }
}

export default App
