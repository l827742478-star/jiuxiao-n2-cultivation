import type { Knowledge, Quest, Reading, Realm } from './types'
import { importedGrammar, importedReadings, importedVocab } from './importedKnowledge'
import { collocations, honorifics, transitivity, wordClasses } from './supplementalKnowledge'

export const realms: Realm[] = [
  { name: '凡人境', minXp: 0, tone: '#94a3b8', seal: '凡', unlock: '建立你的第一座修炼台' },
  { name: '炼气期', minXp: 100, tone: '#67e8f9', seal: '气', unlock: '解锁词海基础试炼' },
  { name: '筑基期', minXp: 300, tone: '#60a5fa', seal: '基', unlock: '解锁法诀辨析阵' },
  { name: '金丹期', minXp: 700, tone: '#fbbf24', seal: '丹', unlock: '解锁长难句秘境' },
  { name: '元婴期', minXp: 1300, tone: '#c084fc', seal: '婴', unlock: '解锁书面语与礼法' },
  { name: '化神期', minXp: 2200, tone: '#f472b6', seal: '神', unlock: '解锁作者心念推演' },
  { name: '炼虚期', minXp: 3500, tone: '#fb7185', seal: '虚', unlock: '解锁综合试炼' },
  { name: '合体期', minXp: 5000, tone: '#fb923c', seal: '合', unlock: '解锁限时渡劫' },
  { name: '渡劫期', minXp: 7000, tone: '#facc15', seal: '劫', unlock: '解锁最终天劫' },
  { name: '飞升期', minXp: 10000, tone: '#f8fafc', seal: '升', unlock: '完成N2知识闭环' },
]

const seedVocab: Knowledge[] = [
  { id: 'v-001', kind: 'vocab', title: 'あらかじめ', reading: 'あらかじめ', meaning: '预先，事先', detail: '副词。表示在某个动作或事件发生之前提前完成准备。', example: '必要な書類をあらかじめ用意しておいてください。', exampleZh: '请提前准备好必要的文件。', tags: ['副词', '正式表达', '时间'], level: 'N2核心', mastery: '未悟', xp: 2 },
  { id: 'v-002', kind: 'vocab', title: '著しい', reading: 'いちじるしい', meaning: '显著的，明显的', detail: 'い形容词。多用于书面语，常修饰变化、差异、进步等。', example: '技術の進歩は著しい。', exampleZh: '技术进步非常显著。', tags: ['い形容词', '书面语', '变化'], level: 'N2核心', mastery: '未悟', xp: 2 },
  { id: 'v-003', kind: 'vocab', title: '予め', reading: 'あらかじめ', meaning: '预先，事先', detail: '汉字写法。与「あらかじめ」同义，在公告和说明文中常见。', example: '参加者は予め登録を済ませてください。', exampleZh: '参加者请预先完成登记。', tags: ['书面语', '公告'], level: 'N2扩展', mastery: '未悟', xp: 2 },
  { id: 'v-004', kind: 'vocab', title: '一応', reading: 'いちおう', meaning: '姑且，暂且；大致', detail: '副词。表示先完成最低限度的准备，也可表示不完全确定。', example: '一応、師匠に報告しておこう。', exampleZh: '姑且先向师父报告一下吧。', tags: ['副词', '会话'], level: 'N2核心', mastery: '未悟', xp: 2 },
  { id: 'v-005', kind: 'vocab', title: '促す', reading: 'うながす', meaning: '催促；促进；促使', detail: '五段动词。他动词。常见搭配有「注意を促す」「成長を促す」。', example: '掲示板は弟子たちに注意を促した。', exampleZh: '公告栏提醒了弟子们注意。', tags: ['他动词', '正式表达'], level: 'N2核心', mastery: '未悟', xp: 2 },
  { id: 'v-006', kind: 'vocab', title: '概ね', reading: 'おおむね', meaning: '大致，大体上', detail: '副词。用于概括判断，常见于报告、说明和评价。', example: '修行の成果は概ね良好だ。', exampleZh: '修行成果总体良好。', tags: ['副词', '书面语', '评价'], level: 'N2核心', mastery: '未悟', xp: 2 },
  { id: 'v-007', kind: 'vocab', title: 'およそ', reading: 'およそ', meaning: '大约；大致；根本不', detail: '副词。接数量表示约数，也可用于强烈否定。', example: '完成までおよそ三日かかる。', exampleZh: '完成大约需要三天。', tags: ['副词', '数量'], level: 'N2核心', mastery: '未悟', xp: 2 },
  { id: 'v-008', kind: 'vocab', title: 'かえって', reading: 'かえって', meaning: '反而', detail: '副词。结果与预期相反时使用。', example: '急いだ結果、かえって遅れてしまった。', exampleZh: '因为着急，反而迟到了。', tags: ['副词', '结果'], level: 'N2核心', mastery: '未悟', xp: 2 },
  { id: 'v-009', kind: 'vocab', title: '該当する', reading: 'がいとうする', meaning: '符合；相当于', detail: 'サ变动词。用于规则、条件、申请资格等正式场景。', example: '条件に該当する者は申し出てください。', exampleZh: '符合条件者请提出申请。', tags: ['サ变动词', '规则'], level: 'N2核心', mastery: '未悟', xp: 2 },
  { id: 'v-010', kind: 'vocab', title: 'かつて', reading: 'かつて', meaning: '曾经，以前', detail: '副词。多用于书面语，常与过去事实搭配。', example: 'かつてこの山には大きな寺があった。', exampleZh: '以前这座山上有一座大寺庙。', tags: ['副词', '书面语', '时间'], level: 'N2核心', mastery: '未悟', xp: 2 },
  { id: 'v-011', kind: 'vocab', title: '兼ねる', reading: 'かねる', meaning: '兼任；难以；不能贸然', detail: '一段动词。作为补助表达「～かねる」表示因立场或情理难以做某事。', example: 'その申し出には賛成しかねます。', exampleZh: '对于那个提议，我难以赞成。', tags: ['一段动词', '礼法', '否定'], level: 'N2核心', mastery: '未悟', xp: 2 },
  { id: 'v-012', kind: 'vocab', title: '極めて', reading: 'きわめて', meaning: '极其，非常', detail: '副词。正式书面表达，语气比「とても」更强。', example: 'この法器は極めて貴重だ。', exampleZh: '这件法器极其珍贵。', tags: ['副词', '正式表达', '程度'], level: 'N2核心', mastery: '未悟', xp: 2 },
  { id: 'v-013', kind: 'vocab', title: '緩和', reading: 'かんわ', meaning: '缓和，缓解', detail: '名词／サ变动词。常用于紧张、限制、症状和政策。', example: '規則が一部緩和された。', exampleZh: '规则得到了一部分放宽。', tags: ['名词', 'サ变动词', '制度'], level: 'N2核心', mastery: '未悟', xp: 2 },
  { id: 'v-014', kind: 'vocab', title: '見込む', reading: 'みこむ', meaning: '预料；估计；期待', detail: '五段动词。他动词。常与数量、结果和收益搭配。', example: '今年は大幅な成長が見込まれる。', exampleZh: '预计今年会有大幅增长。', tags: ['他动词', '预测'], level: 'N2核心', mastery: '未悟', xp: 2 },
  { id: 'v-015', kind: 'vocab', title: '妨げる', reading: 'さまたげる', meaning: '妨碍，阻碍', detail: '一段动词。他动词。与「集中」「発展」「進行」等搭配。', example: '雑念が修行を妨げる。', exampleZh: '杂念会妨碍修行。', tags: ['他动词', '心理'], level: 'N2核心', mastery: '未悟', xp: 2 },
  { id: 'v-016', kind: 'vocab', title: '遂げる', reading: 'とげる', meaning: '完成；实现；达到', detail: '一段动词。常见「成功を遂げる」「発展を遂げる」。', example: '彼は長年の修行を遂げた。', exampleZh: '他完成了多年的修行。', tags: ['他动词', '成就'], level: 'N2核心', mastery: '未悟', xp: 2 },
  { id: 'v-017', kind: 'vocab', title: '伴う', reading: 'ともなう', meaning: '伴随；带来；相应', detail: '五段动词。自动词和他动词用法皆有，常见于正式说明。', example: '力には責任が伴う。', exampleZh: '力量伴随着责任。', tags: ['自动词', '正式表达', '因果'], level: 'N2核心', mastery: '未悟', xp: 2 },
  { id: 'v-018', kind: 'vocab', title: '捉える', reading: 'とらえる', meaning: '抓住；理解；看待', detail: '一段动词。他动词。抽象用法常见于阅读文章。', example: '現象を正しく捉える必要がある。', exampleZh: '有必要正确理解这一现象。', tags: ['他动词', '阅读'], level: 'N2核心', mastery: '未悟', xp: 2 },
  { id: 'v-019', kind: 'vocab', title: '乏しい', reading: 'とぼしい', meaning: '缺乏，不足', detail: 'い形容词。常与「経験」「想像力」「資源」搭配。', example: '実戦経験が乏しい。', exampleZh: '实战经验不足。', tags: ['い形容词', '评价'], level: 'N2核心', mastery: '未悟', xp: 2 },
  { id: 'v-020', kind: 'vocab', title: '率直', reading: 'そっちょく', meaning: '直率，坦率', detail: 'な形容词／名词。表达不拐弯抹角的态度。', example: '率直な意見を聞かせてください。', exampleZh: '请告诉我坦率的意见。', tags: ['な形容词', '人际'], level: 'N2核心', mastery: '未悟', xp: 2 },
  { id: 'v-021', kind: 'vocab', title: '相次ぐ', reading: 'あいつぐ', meaning: '接连发生', detail: '五段动词。常见于新闻，主语多为事件或事故。', example: '各地で異変が相次いでいる。', exampleZh: '各地接连发生异常现象。', tags: ['新闻', '自动词'], level: 'N2扩展', mastery: '未悟', xp: 2 },
  { id: 'v-022', kind: 'vocab', title: '一概に', reading: 'いちがいに', meaning: '一概地，笼统地', detail: '副词。多与否定搭配「一概に～とは言えない」。', example: '一概に悪いとは言えない。', exampleZh: '不能一概说是坏的。', tags: ['副词', '部分否定'], level: 'N2核心', mastery: '未悟', xp: 2 },
  { id: 'v-023', kind: 'vocab', title: '円滑', reading: 'えんかつ', meaning: '顺利，圆满', detail: 'な形容词／名词。常用于交流、运行、推进。', example: '話し合いを円滑に進める。', exampleZh: '顺利推进讨论。', tags: ['な形容词', '职场'], level: 'N2核心', mastery: '未悟', xp: 2 },
  { id: 'v-024', kind: 'vocab', title: '大げさ', reading: 'おおげさ', meaning: '夸张，夸大', detail: 'な形容词。可修饰说法、动作和反应。', example: '少し大げさに聞こえる。', exampleZh: '听起来有点夸张。', tags: ['な形容词', '评价'], level: 'N2核心', mastery: '未悟', xp: 2 },
  { id: 'v-025', kind: 'vocab', title: 'おおむね', reading: 'おおむね', meaning: '大致，大体', detail: '正式副词，与「概ね」同义。', example: '計画はおおむね順調だ。', exampleZh: '计划大体顺利。', tags: ['副词', '正式表达'], level: 'N2核心', mastery: '未悟', xp: 2 },
  { id: 'v-026', kind: 'vocab', title: 'かろうじて', reading: 'かろうじて', meaning: '好不容易，勉强', detail: '副词。表示在困难条件下勉强达到。', example: 'かろうじて試験に合格した。', exampleZh: '好不容易通过了考试。', tags: ['副词', '结果'], level: 'N2扩展', mastery: '未悟', xp: 2 },
  { id: 'v-027', kind: 'vocab', title: '着実', reading: 'ちゃくじつ', meaning: '踏实，稳步', detail: 'な形容词／名词。常与「進歩」「成長」「実績」搭配。', example: '着実に力を伸ばしている。', exampleZh: '正在稳步提升实力。', tags: ['な形容词', '变化'], level: 'N2核心', mastery: '未悟', xp: 2 },
  { id: 'v-028', kind: 'vocab', title: '著者', reading: 'ちょしゃ', meaning: '作者', detail: '名词。阅读题中常用于判断文章观点归属。', example: '著者の主張をまとめる。', exampleZh: '概括作者的主张。', tags: ['名词', '阅读'], level: '基础复现', mastery: '未悟', xp: 2 },
  { id: 'v-029', kind: 'vocab', title: '適切', reading: 'てきせつ', meaning: '恰当，适当', detail: 'な形容词。常见于选项判断和正式说明。', example: '最も適切なものを選びなさい。', exampleZh: '请选择最恰当的一项。', tags: ['な形容词', '考试表达'], level: 'N2核心', mastery: '未悟', xp: 2 },
  { id: 'v-030', kind: 'vocab', title: '不可欠', reading: 'ふかけつ', meaning: '不可或缺', detail: 'な形容词／名词。多用于必要条件的说明。', example: '日々の復習は合格に不可欠だ。', exampleZh: '每日复习对于通过考试不可或缺。', tags: ['な形容词', '必要'], level: 'N2核心', mastery: '未悟', xp: 2 },
]

function uniqueKnowledge(items: Knowledge[]): Knowledge[] {
  const seen = new Set<string>()
  return items.filter((item) => {
    const key = `${item.kind}|${item.title.trim()}|${item.reading?.trim() ?? ''}`
    if (seen.has(key)) return false
    seen.add(key)
    return true
  })
}

export const vocab: Knowledge[] = uniqueKnowledge([...seedVocab, ...importedVocab])

const seedKanji: Knowledge[] = [
  { id: 'k-001', kind: 'kanji', title: '維', reading: 'イ', meaning: '维持；维系', detail: '常见词：維持（いじ）、維持する。', example: '集中力を維持する。', exampleZh: '维持集中力。', tags: ['书面语', '变化'], level: 'N2核心', mastery: '未悟', xp: 2 },
  { id: 'k-002', kind: 'kanji', title: '益', reading: 'エキ・ヤク', meaning: '益处；增加', detail: '常见词：利益（りえき）、有益（ゆうえき）。', example: '修行には多くの利益がある。', exampleZh: '修行有许多益处。', tags: ['经济', '评价'], level: 'N2核心', mastery: '未悟', xp: 2 },
  { id: 'k-003', kind: 'kanji', title: '援', reading: 'エン', meaning: '援助，支援', detail: '常见词：支援（しえん）、援助（えんじょ）。', example: '仲間の支援を受ける。', exampleZh: '得到同伴的支援。', tags: ['社会', '人际'], level: 'N2核心', mastery: '未悟', xp: 2 },
  { id: 'k-004', kind: 'kanji', title: '沿', reading: 'エン・そう', meaning: '沿着；遵循', detail: '常见词：沿岸（えんがん）、方針に沿う。', example: '計画に沿って進める。', exampleZh: '按照计划推进。', tags: ['正式表达', '规则'], level: 'N2核心', mastery: '未悟', xp: 2 },
  { id: 'k-005', kind: 'kanji', title: '介', reading: 'カイ', meaning: '介入；介绍；介护', detail: '常见词：紹介（しょうかい）、介護（かいご）。', example: '師匠を介して情報を得た。', exampleZh: '通过师父获得了信息。', tags: ['人际', '书面语'], level: 'N2核心', mastery: '未悟', xp: 2 },
  { id: 'k-006', kind: 'kanji', title: '拡', reading: 'カク', meaning: '扩大，扩展', detail: '常见词：拡大（かくだい）、拡張（かくちょう）。', example: '知識の幅を拡大する。', exampleZh: '扩大知识面。', tags: ['变化', '学习'], level: '基础复现', mastery: '未悟', xp: 2 },
  { id: 'k-007', kind: 'kanji', title: '含', reading: 'ガン・ふくむ', meaning: '包含；含有', detail: '常见词：含む（ふくむ）、含意（がんい）。', example: '例外を含む規則だ。', exampleZh: '这是包含例外的规则。', tags: ['阅读', '规则'], level: 'N2核心', mastery: '未悟', xp: 2 },
  { id: 'k-008', kind: 'kanji', title: '幹', reading: 'カン・みき', meaning: '主干；核心', detail: '常见词：幹部（かんぶ）、幹線（かんせん）。', example: '問題の本質を見抜く。', exampleZh: '看穿问题的本质。', tags: ['抽象', '阅读'], level: 'N2扩展', mastery: '未悟', xp: 2 },
  { id: 'k-009', kind: 'kanji', title: '貴', reading: 'キ・とうとい', meaning: '贵重；尊贵', detail: '常见词：貴重（きちょう）、貴重品（きちょうひん）。', example: '貴重な経験になった。', exampleZh: '成为了宝贵的经验。', tags: ['评价', '经历'], level: 'N2核心', mastery: '未悟', xp: 2 },
  { id: 'k-010', kind: 'kanji', title: '逆', reading: 'ギャク・さか', meaning: '相反；逆向', detail: '常见词：逆に（ぎゃくに）、逆効果（ぎゃくこうか）。', example: '努力が逆効果になることもある。', exampleZh: '努力有时也会适得其反。', tags: ['结果', '比较'], level: 'N2核心', mastery: '未悟', xp: 2 },
  { id: 'k-011', kind: 'kanji', title: '境', reading: 'キョウ・さかい', meaning: '境界；环境', detail: '常见词：環境（かんきょう）、境界（きょうかい）。', example: '学習環境を整える。', exampleZh: '整理学习环境。', tags: ['环境', '学习'], level: '基础复现', mastery: '未悟', xp: 2 },
  { id: 'k-012', kind: 'kanji', title: '筋', reading: 'キン・すじ', meaning: '筋；道理；路线', detail: '常见词：筋道（すじみち）、筋肉（きんにく）。', example: '話の筋道を確認する。', exampleZh: '确认文章的逻辑脉络。', tags: ['阅读', '逻辑'], level: 'N2核心', mastery: '未悟', xp: 2 },
  { id: 'k-013', kind: 'kanji', title: '傾', reading: 'ケイ・かたむく', meaning: '倾斜；倾向', detail: '常见词：傾向（けいこう）、傾ける（かたむける）。', example: '若者の意識の傾向を調べる。', exampleZh: '调查年轻人的意识倾向。', tags: ['统计', '阅读'], level: 'N2核心', mastery: '未悟', xp: 2 },
  { id: 'k-014', kind: 'kanji', title: '効', reading: 'コウ・きく', meaning: '效果；奏效', detail: '常见词：効果（こうか）、有効（ゆうこう）。', example: '復習の効果を実感する。', exampleZh: '切身体会到复习的效果。', tags: ['学习', '评价'], level: '基础复现', mastery: '未悟', xp: 2 },
  { id: 'k-015', kind: 'kanji', title: '裁', reading: 'サイ・たつ', meaning: '裁决；裁剪', detail: '常见词：裁判（さいばん）、判断を下す。', example: '冷静な判断を下す。', exampleZh: '做出冷静的判断。', tags: ['法律', '判断'], level: 'N2扩展', mastery: '未悟', xp: 2 },
  { id: 'k-016', kind: 'kanji', title: '識', reading: 'シキ', meaning: '认识；知识', detail: '常见词：知識（ちしき）、意識（いしき）。', example: '知識を実戦で使う。', exampleZh: '在实战中使用知识。', tags: ['学习', '抽象'], level: '基础复现', mastery: '未悟', xp: 2 },
  { id: 'k-017', kind: 'kanji', title: '損', reading: 'ソン・そこなう', meaning: '损失；损害', detail: '常见词：損失（そんしつ）、損なう（そこなう）。', example: '信頼を損なう。', exampleZh: '损害信任。', tags: ['社会', '评价'], level: 'N2核心', mastery: '未悟', xp: 2 },
  { id: 'k-018', kind: 'kanji', title: '適', reading: 'テキ', meaning: '适合；恰当', detail: '常见词：適切（てきせつ）、適用（てきよう）。', example: '適切な方法を選ぶ。', exampleZh: '选择恰当的方法。', tags: ['评价', '规则'], level: '基础复现', mastery: '未悟', xp: 2 },
]

export const kanji: Knowledge[] = seedKanji

const seedGrammar: Knowledge[] = [
  { id: 'g-001', kind: 'grammar', title: '～わけではない', reading: 'わけではない', meaning: '并不是……；未必……', detail: '接普通形。用于部分否定，否定对方可能的过度推断。', example: '毎日勉強すれば、必ず合格できるわけではない。', exampleZh: '每天学习也不一定就能通过。', tags: ['部分否定', '辨析阵'], level: 'N2核心', mastery: '未悟', xp: 10, related: ['g-017'] },
  { id: 'g-002', kind: 'grammar', title: '～に違いない', reading: 'にちがいない', meaning: '一定……；肯定……', detail: '接普通形。说话人根据依据做出强烈推测。', example: '彼はすでにこの法則を知っているに違いない。', exampleZh: '他一定已经知道这条法则了。', tags: ['推测', '判断'], level: 'N2核心', mastery: '未悟', xp: 10 },
  { id: 'g-003', kind: 'grammar', title: '～たびに', reading: 'たびに', meaning: '每当……就……', detail: '接动词辞书形或名词＋の。表示同一情况反复发生。', example: 'この文章を読むたびに新しい発見がある。', exampleZh: '每次读这篇文章都会有新的发现。', tags: ['时间', '重复'], level: 'N2核心', mastery: '未悟', xp: 10 },
  { id: 'g-004', kind: 'grammar', title: '～に伴って', reading: 'にともなって', meaning: '随着……；伴随……', detail: '接名词或动词辞书形。书面语，表示变化同步发生。', example: '修為の上昇に伴って、試練も難しくなる。', exampleZh: '随着修为提升，试炼也会变难。', tags: ['变化', '书面语'], level: 'N2核心', mastery: '未悟', xp: 10 },
  { id: 'g-005', kind: 'grammar', title: '～わけにはいかない', reading: 'わけにはいかない', meaning: '不能……；不可以……', detail: '接动词辞书形。因为责任、常识或立场而不能做某事。', example: '約束した以上、途中で逃げるわけにはいかない。', exampleZh: '既然约定了，就不能中途逃跑。', tags: ['义务', '立场'], level: 'N2核心', mastery: '未悟', xp: 10 },
  { id: 'g-006', kind: 'grammar', title: '～あげく', reading: 'あげく', meaning: '最后……；结果……', detail: '接动词た形或名词＋の。多用于经过长时间或反复后产生不理想结果。', example: '迷ったあげく、古い道を選んだ。', exampleZh: '犹豫了半天，最后选择了旧路。', tags: ['结果', '负面'], level: 'N2核心', mastery: '未悟', xp: 10 },
  { id: 'g-007', kind: 'grammar', title: '～からには', reading: 'からには', meaning: '既然……就……', detail: '接普通形。表示既然做出决定，就必须承担后续责任。', example: '修行を始めたからには、最後まで続けたい。', exampleZh: '既然开始修行，就想坚持到最后。', tags: ['理由', '决心'], level: 'N2核心', mastery: '未悟', xp: 10 },
  { id: 'g-008', kind: 'grammar', title: '～うちに', reading: 'うちに', meaning: '趁着……；在……过程中', detail: '接名词＋の、い形容词、な形容词或动词。表示状态变化前完成动作。', example: '忘れないうちに、修行記録を書いておこう。', exampleZh: '趁还没忘，先写下修行记录吧。', tags: ['时间', '变化'], level: 'N2核心', mastery: '未悟', xp: 10 },
  { id: 'g-009', kind: 'grammar', title: '～ばかりに', reading: 'ばかりに', meaning: '只因为……而导致遗憾结果', detail: '接普通形。后项通常是不理想的结果。', example: '一問を油断したばかりに、合格を逃した。', exampleZh: '只因为一道题疏忽，就错过了合格。', tags: ['原因', '负面'], level: 'N2核心', mastery: '未悟', xp: 10 },
  { id: 'g-010', kind: 'grammar', title: '～に応じて', reading: 'におうじて', meaning: '根据……；按照……', detail: '接名词。表示根据条件、程度、情况进行相应变化。', example: '実力に応じて試練の強さを調整する。', exampleZh: '根据实力调整试炼强度。', tags: ['对应', '规则'], level: 'N2核心', mastery: '未悟', xp: 10 },
  { id: 'g-011', kind: 'grammar', title: '～を問わず', reading: 'をとわず', meaning: '不论……；不问……', detail: '接名词。表示不受某一条件限制。', example: '経験の有無を問わず参加できる。', exampleZh: '无论有没有经验都可以参加。', tags: ['限制', '正式语'], level: 'N2核心', mastery: '未悟', xp: 10 },
  { id: 'g-012', kind: 'grammar', title: '～わりに', reading: 'わりに', meaning: '虽然……但是……；与……相比', detail: '接普通形或名词＋の。表示与预想、标准不一致。', example: 'この法诀は簡単なわりに効果が高い。', exampleZh: '这条法诀虽然简单，效果却很高。', tags: ['比较', '评价'], level: 'N2核心', mastery: '未悟', xp: 10 },
  { id: 'g-013', kind: 'grammar', title: '～て以来', reading: 'ていらい', meaning: '自从……以来', detail: '接动词て形。表示从过去某时起一直持续到现在。', example: '修行を始めて以来、生活が変わった。', exampleZh: '自从开始修行以来，生活发生了变化。', tags: ['时间', '持续'], level: 'N2核心', mastery: '未悟', xp: 10 },
  { id: 'g-014', kind: 'grammar', title: '～ことから', reading: 'ことから', meaning: '由于……；从……这一点来看', detail: '接普通形。用于说明判断依据或名称、由来。', example: '形が鳥に似ていることから、その山は鳥山と呼ばれた。', exampleZh: '由于形状像鸟，那座山被称为鸟山。', tags: ['依据', '说明'], level: 'N2核心', mastery: '未悟', xp: 10 },
  { id: 'g-015', kind: 'grammar', title: '～にほかならない', reading: 'にほかならない', meaning: '正是……；无非是……', detail: '接名词。用于强调判断，书面语色彩强。', example: '継続こそが、最大の力にほかならない。', exampleZh: '坚持正是最大的力量。', tags: ['强调', '书面语'], level: 'N2扩展', mastery: '未悟', xp: 10 },
  { id: 'g-016', kind: 'grammar', title: '～ざるを得ない', reading: 'ざるをえない', meaning: '不得不……', detail: '接动词未然形，する变为せざるを得ない。表示没有其他选择。', example: '証拠がないため、計画を延期せざるを得ない。', exampleZh: '因为没有证据，不得不推迟计划。', tags: ['义务', '书面语'], level: 'N2核心', mastery: '未悟', xp: 10 },
  { id: 'g-017', kind: 'grammar', title: '～とは限らない', reading: 'とはかぎらない', meaning: '未必……；不一定……', detail: '接普通形。表示一般判断并非总是成立。', example: '難しい法诀が、役に立つとは限らない。', exampleZh: '难的法诀未必有用。', tags: ['部分否定', '判断'], level: 'N2核心', mastery: '未悟', xp: 10, related: ['g-001'] },
  { id: 'g-018', kind: 'grammar', title: '～ものの', reading: 'ものの', meaning: '虽然……但是……', detail: '接普通形。书面语，表示前项承认事实但后项出现不同结果。', example: '覚えたものの、実戦では使えなかった。', exampleZh: '虽然记住了，但在实战中没能使用。', tags: ['转折', '书面语'], level: 'N2核心', mastery: '未悟', xp: 10 },
  { id: 'g-019', kind: 'grammar', title: '～に際して', reading: 'にさいして', meaning: '在……之际', detail: '接名词或动词辞书形。正式表达，用于重要场合。', example: '渡劫に際して、師匠から助言を受けた。', exampleZh: '在渡劫之际，接受了师父的建议。', tags: ['时间', '正式语'], level: 'N2核心', mastery: '未悟', xp: 10 },
  { id: 'g-020', kind: 'grammar', title: '～わけだ', reading: 'わけだ', meaning: '难怪……；也就是说……', detail: '接普通形。表示根据已知信息得出合乎逻辑的结论。', example: '毎日復習している。道心が強いわけだ。', exampleZh: '每天都在复习，难怪道心这么强。', tags: ['结论', '推理'], level: 'N2核心', mastery: '未悟', xp: 10 },
]

export const grammar: Knowledge[] = uniqueKnowledge([...seedGrammar, ...importedGrammar])

const seedReadings: Reading[] = [
  {
    id: 'r-001', kind: 'reading', title: '宗门公告：闭关室的使用规则', reading: 'しゅうもんこうこく', meaning: '公告阅读：规则与条件', detail: '公告类典籍，训练条件、禁止和时间信息提取。', level: 'N2核心', mastery: '未悟', xp: 20, tags: ['公告', '规则', '细节题'], suggestedMinutes: 3,
    body: '本日より、第三閉関室の利用時間を午前六時から午後十時までとする。利用者は入室前に必ず修行記録を提出し、室内では他の弟子の修行を妨げてはならない。なお、満員の場合は予約者を優先するが、予約時間を十分過ぎても現れない場合、予約は無効となる。',
    questions: [
      { prompt: '第三閉関室の利用時間はいつからいつまでか。', options: ['午前六時から午後十時まで', '午前八時から午後八時まで', '午後六時から午後十時まで', '一日中利用できる'], answer: 0, explanation: '公告第一句明确写着「午前六時から午後十時まで」。' },
      { prompt: '予約が無効になるのはどのような場合か。', options: ['記録を提出した場合', '室内で話した場合', '予約時間を十分過ぎても来ない場合', '満員になった場合'], answer: 2, explanation: '关键是「予約時間を十分過ぎても現れない場合」。' },
    ],
  },
  {
    id: 'r-002', kind: 'reading', title: '典籍：持续修炼为何有效', reading: 'けいぞくしゅぎょう', meaning: '说明文阅读：因果与观点', detail: '说明文，训练主旨、原因和作者观点。', level: 'N2核心', mastery: '未悟', xp: 30, tags: ['说明文', '主旨题', '因果'], suggestedMinutes: 5,
    body: '新しい知識を一度に大量に覚えようとすると、短期的には達成感を得られる。しかし、復習の間隔が長くなれば、記憶は次第に薄れてしまう。毎日少しずつ学び、忘れかけた時にもう一度思い出すほうが、結果として知識を長く維持しやすい。重要なのは一日の量ではなく、学習を続ける仕組みを作ることである。',
    questions: [
      { prompt: '文章の主張として最も適切なものはどれか。', options: ['一日に大量に覚えるべきだ', '達成感があれば復習は不要だ', '少量でも継続できる仕組みが重要だ', '記憶は時間が経てば必ず消える'], answer: 2, explanation: '最后一句「一日の量ではなく、学習を続ける仕組み」概括了全文主张。' },
      { prompt: '「忘れかけた時にもう一度思い出す」目的は何か。', options: ['学習時間を短くするため', '知識を長く維持するため', '達成感を得るため', '新しい知識を避けるため'], answer: 1, explanation: '前文说明间隔复习可以让知识更长久地保留。' },
    ],
  },
  {
    id: 'r-003', kind: 'reading', title: '修士议论：便利与选择', reading: 'べんりさとせんたく', meaning: '议论文阅读：对比与让步', detail: '议论类典籍，训练转折、对比和作者态度。', level: 'N2扩展', mastery: '未悟', xp: 40, tags: ['议论文', '对比', '作者态度'], suggestedMinutes: 6,
    body: '便利な道具が増えれば、私たちの生活は確かに楽になる。その一方で、選択肢が多すぎると、何を選ぶべきか迷う時間も増える。したがって、便利さを求めるだけでは十分ではない。自分に必要なものを判断する基準を持ってこそ、道具を有効に使えるのである。',
    questions: [
      { prompt: '便利な道具が増えることの問題点は何か。', options: ['生活が楽にならないこと', '道具を使えなくなること', '選択に迷う時間が増えること', '選択肢が減ること'], answer: 2, explanation: '「選択肢が多すぎると、何を選ぶべきか迷う時間も増える」とある。' },
      { prompt: '筆者は何が必要だと考えているか。', options: ['すべての道具を買うこと', '便利さを拒否すること', '必要なものを判断する基準を持つこと', '選択肢を増やし続けること'], answer: 2, explanation: '最后一句直接指出判断标准的重要性。' },
    ],
  },
]

export const readings: Reading[] = uniqueKnowledge([...seedReadings, ...importedReadings]) as Reading[]

export const quests: Quest[] = [
  { id: 'q-vocab', title: '词海纳气', body: '研读10枚词海灵符，稳固今日根基。', rewardXp: 25, rewardStones: 5, targetKind: 'vocab', target: 10 },
  { id: 'q-grammar', title: '法诀参悟', body: '参悟2道N2法诀，并写下你的悟道批注。', rewardXp: 30, rewardStones: 5, targetKind: 'grammar', target: 2 },
  { id: 'q-reading', title: '典籍破阵', body: '完成1卷典籍试炼，找出文章的主阵眼。', rewardXp: 35, rewardStones: 8, targetKind: 'reading', target: 1 },
]

export const coverage = [
  { name: '词海（N2重点）', current: vocab.length, target: 2000, tone: 'blue' },
  { name: '法诀（N2句型）', current: grammar.length, target: Math.max(200, grammar.length), tone: 'gold' },
  { name: '礼法与正式表达', current: honorifics.length, target: honorifics.length, tone: 'purple' },
  { name: '合璧术与惯用搭配', current: collocations.length, target: collocations.length, tone: 'rose' },
  { name: '典籍试炼', current: readings.length, target: Math.max(40, readings.length), tone: 'orange' },
  { name: '词类与活用辨析', current: wordClasses.length, target: wordClasses.length, tone: 'cyan' },
  { name: '自动词·他动词', current: transitivity.length, target: transitivity.length, tone: 'blue' },
]
