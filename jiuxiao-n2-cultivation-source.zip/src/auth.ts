import type { UserState } from './types'

export type LocalUser = {
  id: string
  username: string
  displayName: string
  passwordHash: string
  createdAt: string
}

export type AuthResult =
  | { ok: true; user: LocalUser }
  | { ok: false; message: string }

const USERS_KEY = 'jiuxiao-n2-users-v1'
const SESSION_KEY = 'jiuxiao-n2-session-v1'
const PROFILE_PREFIX = 'jiuxiao-n2-profile-v1:'
const LEGACY_STATE_KEY = 'jiuxiao-n2-state-v1'

function canUseStorage() {
  return typeof window !== 'undefined' && typeof window.localStorage !== 'undefined'
}

function readUsers(): Record<string, LocalUser> {
  if (!canUseStorage()) return {}
  try {
    const raw = window.localStorage.getItem(USERS_KEY)
    const parsed = raw ? JSON.parse(raw) : {}
    return parsed && typeof parsed === 'object' ? parsed as Record<string, LocalUser> : {}
  } catch {
    return {}
  }
}

function writeUsers(users: Record<string, LocalUser>) {
  if (canUseStorage()) window.localStorage.setItem(USERS_KEY, JSON.stringify(users))
}

function normalizeUsername(username: string) {
  return username.trim().toLowerCase()
}

function makeUserId() {
  if (typeof crypto !== 'undefined' && 'randomUUID' in crypto) return crypto.randomUUID()
  return `user-${Date.now()}-${Math.random().toString(36).slice(2)}`
}

async function hashPassword(password: string) {
  if (typeof crypto !== 'undefined' && crypto.subtle) {
    const bytes = new TextEncoder().encode(password)
    const digest = await crypto.subtle.digest('SHA-256', bytes)
    return Array.from(new Uint8Array(digest)).map((byte) => byte.toString(16).padStart(2, '0')).join('')
  }

  // 极旧浏览器没有 Web Crypto 时仍不保存明文密码；现代浏览器会走上面的 SHA-256。
  let hash = 2166136261
  for (const char of password) hash = Math.imul(hash ^ char.charCodeAt(0), 16777619)
  return `fallback-${(hash >>> 0).toString(16)}`
}

export async function registerLocalUser(username: string, displayName: string, password: string): Promise<AuthResult> {
  const normalized = normalizeUsername(username)
  const name = displayName.trim() || normalized
  if (normalized.length < 3) return { ok: false, message: '修士账号至少需要 3 个字符' }
  if (password.length < 6) return { ok: false, message: '密码至少需要 6 个字符' }
  if (name.length < 2) return { ok: false, message: '请填写至少 2 个字的档案名' }

  const users = readUsers()
  if (users[normalized]) return { ok: false, message: '这个修士账号已经存在，请直接登录' }
  const user: LocalUser = {
    id: makeUserId(),
    username: normalized,
    displayName: name,
    passwordHash: await hashPassword(password),
    createdAt: new Date().toISOString(),
  }
  users[normalized] = user
  writeUsers(users)
  setSessionUser(user.id)
  return { ok: true, user }
}

export async function loginLocalUser(username: string, password: string): Promise<AuthResult> {
  const normalized = normalizeUsername(username)
  const user = readUsers()[normalized]
  if (!user) return { ok: false, message: '未找到这个修士账号，请先注册' }
  if (user.passwordHash !== await hashPassword(password)) return { ok: false, message: '密码不正确，请再试一次' }
  setSessionUser(user.id)
  return { ok: true, user }
}

export function getCurrentUser(): LocalUser | null {
  if (!canUseStorage()) return null
  const id = window.localStorage.getItem(SESSION_KEY)
  if (!id) return null
  return Object.values(readUsers()).find((user) => user.id === id) ?? null
}

export function setSessionUser(userId: string) {
  if (canUseStorage()) window.localStorage.setItem(SESSION_KEY, userId)
}

export function clearSession() {
  if (canUseStorage()) window.localStorage.removeItem(SESSION_KEY)
}

export function readUserProfile(userId: string, fallback: UserState): UserState {
  const cleanFallback = (): UserState => ({
    ...fallback,
    completedQuestIds: [],
    masteredIds: [],
    heartDemonIds: [],
    activityLog: [],
  })
  if (!canUseStorage()) return cleanFallback()
  const key = `${PROFILE_PREFIX}${userId}`
  try {
    const raw = window.localStorage.getItem(key)
    if (raw) {
      const parsed = JSON.parse(raw)
      // 旧版档案里的修为、时长和准确率是演示数据，不能当成真实学习记录继续使用。
      if (parsed && Array.isArray(parsed.activityLog)) return { ...fallback, ...parsed }
      window.localStorage.removeItem(key)
      return cleanFallback()
    }

    // 把旧版未登录日志只迁移给首次登录的账号，避免以后新账号共享同一份进度。
    const legacy = window.localStorage.getItem(LEGACY_STATE_KEY)
    if (legacy) {
      const parsed = JSON.parse(legacy)
      window.localStorage.removeItem(LEGACY_STATE_KEY)
      // 只有包含真实活动日志的新版档案才允许迁移；旧演示数据直接丢弃。
      if (parsed && Array.isArray(parsed.activityLog)) {
        const migrated = { ...fallback, ...parsed }
        window.localStorage.setItem(key, JSON.stringify(migrated))
        return migrated
      }
    }
  } catch {
    // 损坏的本地档案不应阻塞进入游戏，回退到干净档案。
  }
  return cleanFallback()
}

export function saveUserProfile(userId: string, state: UserState) {
  if (canUseStorage()) window.localStorage.setItem(`${PROFILE_PREFIX}${userId}`, JSON.stringify(state))
}
