export type Realm = {
  name: string
  minXp: number
  tone: string
  seal: string
  unlock: string
}

export type KnowledgeKind = 'vocab' | 'kanji' | 'grammar' | 'reading' | 'honorific' | 'collocation' | 'wordClass' | 'transitivity'
export type Mastery = '未悟' | '修炼中' | '已悟' | '心魔缠身'

export type Knowledge = {
  id: string
  kind: KnowledgeKind
  title: string
  reading?: string
  meaning: string
  detail: string
  example?: string
  exampleZh?: string
  tags: string[]
  level: '基础复现' | 'N2核心' | 'N2扩展'
  mastery: Mastery
  xp: number
  reviewAt?: string
  related?: string[]
  sourceName?: string
  sourceRow?: number
  sourceLevel?: string
  sourceFields?: { label: string; value: string }[]
}

export type ReadingQuestion = {
  prompt: string
  options: string[]
  answer: number
  explanation: string
}

export type Reading = Knowledge & {
  kind: 'reading'
  body: string
  translation?: string
  readingNotes?: string
  questions: ReadingQuestion[]
  suggestedMinutes: number
}

export type Quest = {
  id: string
  title: string
  body: string
  rewardXp: number
  rewardStones: number
  targetKind: KnowledgeKind | 'any'
  target: number
}

export type UserState = {
  xp: number
  stones: number
  streak: number
  lastActive: string | null
  completedQuestIds: string[]
  masteredIds: string[]
  heartDemonIds: string[]
  attempts: number
  correct: number
  meditationMinutes: number
  title: string
}
