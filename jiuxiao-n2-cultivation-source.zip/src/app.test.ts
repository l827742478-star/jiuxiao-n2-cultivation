import { describe, expect, it } from 'vitest'
import { grammar, kanji, realms, readings, vocab } from './data'
import { importedGrammar, importedReadings, importedStats, importedVocab } from './importedKnowledge'
import { collocations, honorifics, supplementalKnowledge, transitivity, wordClasses } from './supplementalKnowledge'

describe('九霄日语修炼录 content manifest', () => {
  it('ships non-empty knowledge domains', () => {
    expect(vocab.length).toBeGreaterThan(0)
    expect(kanji.length).toBeGreaterThan(0)
    expect(grammar.length).toBeGreaterThan(0)
    expect(readings.length).toBeGreaterThan(0)
  })

  it('keeps every seed knowledge item identifiable and explained', () => {
    const items = [...vocab, ...kanji, ...grammar, ...readings]
    expect(new Set(items.map((item) => item.id)).size).toBe(items.length)
    items.forEach((item) => {
      expect(item.title.length).toBeGreaterThan(0)
      expect(item.meaning.length).toBeGreaterThan(0)
      expect(item.detail.length).toBeGreaterThan(0)
    })
  })

  it('keeps realm thresholds ascending', () => {
    expect(realms.every((realm, index) => index === 0 || realm.minXp > realms[index - 1].minXp)).toBe(true)
  })

  it('keeps every attached export row represented exactly once', () => {
    expect(importedVocab.length).toBe(importedStats.vocabRows)
    expect(importedGrammar.length).toBe(importedStats.grammarRows)
    expect(importedReadings.length).toBe(importedStats.readingRows)
    const imported = [...importedVocab, ...importedGrammar, ...importedReadings]
    expect(imported.length).toBe(importedStats.totalRows)
    expect(new Set(imported.map((item) => item.id)).size).toBe(imported.length)
    imported.forEach((item) => {
      expect(item.sourceName).toBeTruthy()
      expect(item.sourceFields?.length).toBeGreaterThan(0)
    })
  })

  it('fills every supplemental domain without duplicate IDs or titles', () => {
    expect(honorifics).toHaveLength(100)
    expect(collocations).toHaveLength(613)
    expect(wordClasses).toHaveLength(80)
    expect(transitivity).toHaveLength(120)
    expect(supplementalKnowledge).toHaveLength(913)
    expect(new Set(supplementalKnowledge.map((item) => item.id)).size).toBe(913)
    expect(new Set(supplementalKnowledge.map((item) => item.title)).size).toBe(913)
    expect(collocations.every((item) => item.level === 'N2核心' && item.sourceName && item.sourceFields?.length)).toBe(true)
    const allKnowledge = [...vocab, ...kanji, ...grammar, ...readings, ...supplementalKnowledge]
    expect(new Set(allKnowledge.map((item) => item.id)).size).toBe(allKnowledge.length)
    const displayKeys = allKnowledge.map((item) => `${item.kind}|${item.title.trim()}|${item.reading?.trim() ?? ''}`)
    expect(new Set(displayKeys).size).toBe(displayKeys.length)
  })
})
