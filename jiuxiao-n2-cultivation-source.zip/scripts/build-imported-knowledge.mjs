import fs from 'node:fs'
import path from 'node:path'
import { execFileSync } from 'node:child_process'

const root = process.cwd()
const output = path.join(root, 'src', 'importedKnowledge.ts')

const archives = [
  {
    file: '/Users/lxw2416256/Downloads/658a05da-567a-45f4-bd1f-63f9a36a5b78_ExportBlock-4758d526-fd15-4b55-a889-bf0010866468.zip',
    kind: 'vocab',
    sourceName: '日语N2高频词汇卡片',
  },
  {
    file: '/Users/lxw2416256/Downloads/a769674e-079e-4b27-ae4e-05213f2aa50b_ExportBlock-0db5c2e3-dc3e-4582-8aaa-03a1cb86c6de.zip',
    kind: 'reading',
    sourceName: '日语阅读提分神器｜200篇高频阅读理解训练卡',
  },
  {
    file: '/Users/lxw2416256/Downloads/9d248c25-88e3-486b-b107-ce34d4ffccbf_ExportBlock-3cd30de5-5852-4e02-9d57-74f351a66d4b.zip',
    kind: 'expression',
    sourceName: '高频N2表达',
  },
]

function readCsv(archive) {
  const python = [
    'import base64, json, sys, zipfile',
    'with zipfile.ZipFile(sys.argv[1]) as z:',
    "    names = [name for name in z.namelist() if name.lower().endswith('.csv') and not name.endswith('_all.csv')]",
    "    name = names[0]",
    "    print(json.dumps({'entry': name, 'data': base64.b64encode(z.read(name)).decode('ascii')}))",
  ].join('\n')
  const result = JSON.parse(execFileSync('python3', ['-c', python, archive], { encoding: 'utf8' }))
  return { entry: result.entry, rows: parseCsv(Buffer.from(result.data, 'base64').toString('utf8').replace(/^\uFEFF/, '')) }
}

function parseCsv(text) {
  const rows = []
  let row = []
  let cell = ''
  let quoted = false
  for (let i = 0; i < text.length; i += 1) {
    const char = text[i]
    const next = text[i + 1]
    if (char === '"' && quoted && next === '"') {
      cell += '"'
      i += 1
    } else if (char === '"') {
      quoted = !quoted
    } else if (char === ',' && !quoted) {
      row.push(cell)
      cell = ''
    } else if ((char === '\n' || char === '\r') && !quoted) {
      if (char === '\r' && next === '\n') i += 1
      row.push(cell)
      if (row.some((value) => value.trim() !== '')) rows.push(row)
      row = []
      cell = ''
    } else {
      cell += char
    }
  }
  if (cell !== '' || row.length) {
    row.push(cell)
    if (row.some((value) => value.trim() !== '')) rows.push(row)
  }
  const [header, ...body] = rows
  return body.map((values) => Object.fromEntries(header.map((key, index) => [key.trim(), (values[index] ?? '').trim()])))
}

function value(row, key) {
  return (row[key] ?? '').trim()
}

function sourceFields(row) {
  return Object.entries(row)
    .filter(([, fieldValue]) => fieldValue.trim() !== '')
    .map(([label, fieldValue]) => ({ label, value: fieldValue.trim() }))
}

function level(raw, fallback = 'N2核心') {
  if (/N4|N3/.test(raw)) return '基础复现'
  if (/N2/.test(raw)) return 'N2核心'
  if (/简单|基础|熟悉/.test(raw)) return '基础复现'
  if (/困难|较难|陌生/.test(raw)) return 'N2扩展'
  return fallback
}

function tags(...values) {
  return [...new Set(values.flatMap((item) => item.split(/[、，,；;｜|]/).map((part) => part.trim()).filter(Boolean)))].slice(0, 8)
}

function extractReading(title) {
  const match = title.match(/[（(]([^）)]+)[）)]$/)
  return match ? match[1] : undefined
}

function vocabItems(rows, sourceName) {
  return rows.map((row, index) => {
    const title = value(row, '日语单词')
    const meaning = value(row, '中文释义')
    const detail = [
      value(row, '词性') && `词性：${value(row, '词性')}`,
      value(row, '高频率') && `出现频率：${value(row, '高频率')}`,
      value(row, '易混词对比') && `易混辨析：${value(row, '易混词对比')}`,
      value(row, '语法链接') && `语法链接：${value(row, '语法链接')}`,
      value(row, '场景分类') && `场景：${value(row, '场景分类')}`,
      value(row, '使用频率') && `使用频率：${value(row, '使用频率')}`,
    ].filter(Boolean).join('；')
    return {
      id: `att-vocab-${String(index + 1).padStart(4, '0')}`,
      kind: 'vocab',
      title,
      reading: value(row, '假名') || undefined,
      meaning,
      detail: detail || '附卷词汇卡，已纳入词海纳气。',
      example: value(row, '例句（日语）') || undefined,
      exampleZh: value(row, '例句中文翻译') || undefined,
      tags: tags(value(row, '词性'), value(row, '高频率'), value(row, '场景分类'), '附卷词海'),
      level: level(value(row, '难度等级')),
      sourceLevel: value(row, '难度等级') || undefined,
      mastery: '未悟',
      xp: 2,
      sourceName,
      sourceRow: Number(value(row, '编号')) || index + 1,
      sourceFields: sourceFields(row),
    }
  })
}

function expressionItems(rows, sourceName) {
  return rows.map((row, index) => {
    const rawTitle = value(row, '标题')
    const isGrammar = value(row, '类型').includes('语法') || /^〜|^～/.test(rawTitle)
    const kind = isGrammar ? 'grammar' : 'vocab'
    const detail = [
      value(row, '接续') && `接续：${value(row, '接续')}`,
      value(row, '类型') && `类型：${value(row, '类型')}`,
      value(row, '标签') && `标签：${value(row, '标签')}`,
      value(row, '出题频率') && `出题频率：${value(row, '出题频率')}`,
      value(row, '难度评分') && `难度评分：${value(row, '难度评分')}`,
      value(row, '熟练度评分') && `熟练度评分：${value(row, '熟练度评分')}`,
    ].filter(Boolean).join('；')
    return {
      id: `att-expression-${String(index + 1).padStart(4, '0')}`,
      kind,
      title: rawTitle,
      reading: extractReading(rawTitle),
      meaning: value(row, '中文解释'),
      detail: detail || '附卷表达卡，已纳入法诀参悟。',
      example: value(row, '例句') || undefined,
      tags: tags(value(row, '类型'), value(row, '标签'), value(row, '出题频率'), '附卷表达'),
      level: level(`${value(row, '难度评分')} ${value(row, '出题频率')}`, isGrammar ? 'N2核心' : 'N2扩展'),
      sourceLevel: value(row, '难度评分') || undefined,
      mastery: '未悟',
      xp: isGrammar ? 10 : 2,
      sourceName,
      sourceRow: Number(value(row, '编号')) || index + 1,
      sourceFields: sourceFields(row),
    }
  })
}

function readingItems(rows, sourceName) {
  return rows.map((row, index) => {
    const solution = value(row, '解题思路') || '先回到日语原文定位主旨、转折、因果与范围。'
    return {
      id: `att-reading-${String(index + 1).padStart(4, '0')}`,
      kind: 'reading',
      title: value(row, '标题') || `附卷典籍 ${index + 1}`,
      meaning: '阅读理解：原文、译文、解题思路与词法批注',
      detail: solution,
      level: level(value(row, '难度等级'), 'N2扩展'),
      sourceLevel: value(row, '难度等级') || undefined,
      mastery: '未悟',
      xp: 20,
      tags: tags(value(row, '适用场景'), value(row, '使用频率'), '附卷典籍'),
      body: value(row, '日语原文'),
      translation: value(row, '中文翻译'),
      readingNotes: solution,
      questions: [{
        prompt: '阅读这卷典籍后，首先应抓住哪项破阵线索？',
        options: [solution, '只记标题，不回到原文定位依据', '只看中文翻译，不判断日语句间关系', '只背单个词汇，不判断文章主旨'],
        answer: 0,
        explanation: `附卷解题思路：${solution}`,
      }],
      suggestedMinutes: 3,
      sourceName,
      sourceRow: Number(value(row, '编号')) || index + 1,
      sourceFields: sourceFields(row),
    }
  })
}

const tables = archives.map((archive) => {
  const table = readCsv(archive.file)
  if (!table.entry) throw new Error(`没有找到 CSV：${archive.file}`)
  return { ...archive, ...table }
})

const importedVocab = vocabItems(tables[0].rows, tables[0].sourceName)
const importedExpressions = expressionItems(tables[2].rows, tables[2].sourceName)
const importedReadings = readingItems(tables[1].rows, tables[1].sourceName)
const vocab = [...importedVocab, ...importedExpressions.filter((item) => item.kind === 'vocab')]
const grammar = importedExpressions.filter((item) => item.kind === 'grammar')
const encode = (value) => `JSON.parse(${JSON.stringify(JSON.stringify(value))})`
const payload = `// Generated from the three user-provided CSV exports. Do not edit by hand.\nimport type { Knowledge, Reading } from './types'\n\nexport const importedVocab: Knowledge[] = ${encode(vocab)}\n\nexport const importedGrammar: Knowledge[] = ${encode(grammar)}\n\nexport const importedReadings: Reading[] = ${encode(importedReadings)}\n\nexport const importedStats = ${JSON.stringify({
  archiveCount: archives.length,
  sourceRows: tables.map(({ sourceName, entry, rows }) => ({ sourceName, entry, rows: rows.length })),
  vocabRows: vocab.length,
  grammarRows: grammar.length,
  readingRows: importedReadings.length,
  totalRows: vocab.length + grammar.length + importedReadings.length,
}, null, 2)} as const\n`

fs.writeFileSync(output, payload)
console.log(JSON.stringify({ output, ...JSON.parse(payload.match(/export const importedStats = ([\\s\\S]*?) as const/)?.[1] ?? '{}') }, null, 2))
