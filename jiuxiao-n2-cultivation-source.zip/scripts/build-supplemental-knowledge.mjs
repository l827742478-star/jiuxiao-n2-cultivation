import fs from 'node:fs'
import path from 'node:path'

const levels = ['N2核心', 'N2核心', 'N2扩展']

function make(kind, prefix, index, title, reading, meaning, detail, example, exampleZh, tags, xp = 4, level = levels[index % levels.length]) {
  return {
    id: `${prefix}-${String(index + 1).padStart(3, '0')}`,
    kind,
    title,
    reading,
    meaning,
    detail,
    example,
    exampleZh,
    tags,
    level,
    mastery: '未悟',
    xp,
  }
}

const honorificPhrases = [
  ['いらっしゃる（来る）', '相手来临时的尊敬语'], ['いらっしゃる（行く）', '相对方前往动作的尊敬语'], ['いらっしゃる（いる）', '相对方在场状态的尊敬语'],
  ['おいでになる', '来、去、在的尊敬表达'], ['お越しになる', '对方来访的尊敬表达'], ['お見えになる', '对方到来的郑重尊敬表达'], ['おっしゃる', '言う的尊敬语'], ['ご覧になる', '見る的尊敬语'], ['召し上がる', '食べる、飲む的尊敬语'], ['お召しになる', '穿着或乘坐的尊敬表达'],
  ['なさる', 'する的尊敬语'], ['くださる', '对方给予或为我方做某事的尊敬语'], ['ご存じだ', '知っている的尊敬表达'], ['お思いになる', '思う的尊敬表达'], ['お感じになる', '感じる的尊敬表达'], ['お考えになる', '考える的尊敬表达'], ['お使いになる', '使う的尊敬表达'], ['お読みになる', '読む的尊敬表达'], ['お書きになる', '書く的尊敬表达'], ['お聞きになる', '聞く的尊敬表达'],
  ['お話しになる', '話す的尊敬表达'], ['お休みになる', '寝る、休む的尊敬表达'], ['お帰りになる', '帰る的尊敬表达'], ['お出かけになる', '出かける的尊敬表达'], ['お待ちになる', '待つ的尊敬表达'], ['お持ちになる', '持つ的尊敬表达'], ['お取りになる', '取る的尊敬表达'], ['お受けになる', '受ける的尊敬表达'], ['お会いになる', '会う的尊敬表达'], ['お借りになる', '借りる的尊敬表达'],
  ['お求めになる', '求める、购买的尊敬表达'], ['ご利用になる', '利用する的尊敬表达'], ['ご確認になる', '確認する的尊敬表达'], ['ご検討になる', '検討する的尊敬表达'], ['ご参加になる', '参加する的尊敬表达'], ['ご出席になる', '出席する的尊敬表达'], ['ご提出になる', '提出する的尊敬表达'], ['ご紹介になる', '紹介する的尊敬表达'], ['ご説明になる', '説明する的尊敬表达'], ['ご連絡になる', '連絡する的尊敬表达'],
  ['ご報告になる', '報告する的尊敬表达'], ['ご相談になる', '相談する的尊敬表达'], ['ご注文になる', '注文する的尊敬表达'], ['ご予約になる', '予約する的尊敬表达'], ['ご登録になる', '登録する的尊敬表达'], ['ご申請になる', '申請する的尊敬表达'], ['ご記入になる', '記入する的尊敬表达'], ['ご協力くださる', '对方给予协助的尊敬请求'], ['ご理解くださる', '请对方理解的尊敬请求'], ['ご配慮くださる', '请对方关照的尊敬请求'],
  ['ご指導くださる', '请对方指导的尊敬请求'], ['ご教示くださる', '请对方指教的尊敬请求'], ['ご確認くださる', '请对方确认的尊敬请求'], ['ご検討くださる', '请对方考虑的尊敬请求'], ['ご連絡くださる', '请对方联系的尊敬请求'], ['ご報告くださる', '请对方报告的尊敬请求'], ['ご参加くださる', '请对方参加的尊敬请求'], ['ご覧くださる', '请对方阅览的尊敬请求'], ['お知らせくださる', '请对方告知的尊敬请求'], ['お越しくださる', '感谢或邀请对方到访的尊敬表达'],
  ['お越しいただく', '承蒙对方到访的谦逊表达'], ['お待ちいただく', '请对方等待的谦逊请求'], ['ご覧いただく', '请对方阅览的谦逊请求'], ['ご確認いただく', '请对方确认的谦逊请求'], ['ご検討いただく', '请对方考虑的谦逊请求'], ['ご理解いただく', '请对方理解的谦逊请求'], ['ご協力いただく', '承蒙对方协助的谦逊表达'], ['ご参加いただく', '请对方参加的谦逊请求'], ['ご連絡いただく', '请对方联系的谦逊请求'], ['ご報告いただく', '请对方报告的谦逊请求'],
  ['ご記入いただく', '请对方填写的谦逊请求'], ['ご提出いただく', '请对方提交的谦逊请求'], ['ご利用いただく', '请对方使用的谦逊请求'], ['ご予約いただく', '请对方预约的谦逊请求'], ['ご登録いただく', '请对方登记的谦逊请求'], ['ご相談いただく', '欢迎对方咨询的谦逊表达'], ['ご容赦いただく', '请对方谅解的谦逊表达'], ['いただく（受益）', '从对方获得物品或恩惠的谦逊语'], ['いただけますか', '礼貌请求对方做某事'], ['いただければ幸いです', '郑重表达如果对方能做某事将不胜感激'],
  ['いただきたく存じます', '郑重表达希望得到对方协助'], ['お願い申し上げる', '郑重恳请对方协助'], ['ご案内申し上げる', '以谦逊语郑重进行 안내或通知'], ['ご説明申し上げる', '以谦逊语郑重说明'], ['ご報告申し上げる', '以谦逊语郑重报告'], ['ご連絡申し上げる', '以谦逊语郑重联系'], ['お詫び申し上げる', '以谦逊语郑重道歉'], ['お礼申し上げる', '以谦逊语郑重致谢'], ['お願いいたす', 'いたす构成的郑重请求'], ['ご案内いたす', 'いたす构成的郑重 안내'],
  ['ご連絡いたす', 'いたす构成的郑重联系'], ['承知する', '理解并接受对方要求的郑重表达'], ['かしこまる', '表示恭敬接受命令或请求'], ['伺う（访问）', '参访对方处所的谦逊语'], ['伺う（询问）', '询问、请教的谦逊语'], ['参る', '行く、来る的谦逊语'], ['申す', '言う的谦逊语'], ['申し上げる', '向对方表达的郑重谦逊语'], ['存じる', '知る、思う的谦逊语'], ['存じ上げる', '对熟悉的人或事项表示知晓的谦逊语'],
]

const honorifics = honorificPhrases.map(([title, meaning], index) => make(
  'honorific', 'hon', index, title, title,
  `礼法表达：${meaning}`,
  `礼法卷辨析「${title}」：确认尊敬方向、受益者和使用场面，不把尊敬语与自谦语混用。`,
  `「${title}」は、改まった場面で相手への敬意を表す。`,
  `“${title}”用于正式场合，表达对对方的敬意。`,
  ['礼法', '正式表达', index < 70 ? '尊敬语' : '谦让语'], 5,
))

function parseCsv(text) {
  const rows = []
  let row = []
  let cell = ''
  let quoted = false
  for (let index = 0; index < text.length; index += 1) {
    const char = text[index]
    const next = text[index + 1]
    if (char === '"' && quoted && next === '"') {
      cell += '"'
      index += 1
    } else if (char === '"') {
      quoted = !quoted
    } else if (char === ',' && !quoted) {
      row.push(cell)
      cell = ''
    } else if ((char === '\n' || char === '\r') && !quoted) {
      if (char === '\r' && next === '\n') index += 1
      row.push(cell)
      if (row.some((value) => value.trim() !== '')) rows.push(row)
      row = []
      cell = ''
    } else {
      cell += char
    }
  }
  row.push(cell)
  if (row.some((value) => value.trim() !== '')) rows.push(row)
  return rows
}

const collocationCsv = fs.readFileSync(path.resolve(process.cwd(), 'data/n2-collocations.csv'), 'utf8').replace(/^\uFEFF/, '')
const [collocationHeaders, ...collocationRecords] = parseCsv(collocationCsv)
const collocationIndex = new Map(collocationHeaders.map((name, index) => [name, index]))
const field = (record, name) => (record[collocationIndex.get(name)] ?? '').trim()
const sourceRows = collocationRecords
  .map((record) => ({
    no: field(record, 'No.'),
    noun: field(record, '核心名词'),
    particle: field(record, '关键助词'),
    verb: field(record, '搭配动词'),
    phrase: field(record, '完整短语'),
    reading: field(record, '假名注音'),
    meaning: field(record, '中文释义'),
    rawExample: field(record, '例句'),
    scene: field(record, '场景标签'),
    level: field(record, 'JLPT等级'),
    error: field(record, '常见错误'),
  }))
  .filter((record) => record.level === 'N2' && record.phrase)

const seenPhrases = new Set()
const collocations = sourceRows
  .filter((record) => {
    const key = record.phrase.replace(/\s+/g, ' ')
    if (seenPhrases.has(key)) return false
    seenPhrases.add(key)
    return true
  })
  .map((record, index) => {
    const [example, ...translationLines] = record.rawExample.split(/\r?\n/)
    const sourceFields = [
      ['编号', record.no], ['核心名词', record.noun], ['关键助词', record.particle], ['搭配动词', record.verb],
      ['完整短语', record.phrase], ['假名注音', record.reading], ['中文释义', record.meaning], ['例句', record.rawExample],
      ['场景标签', record.scene], ['JLPT等级', record.level], ['常见错误', record.error],
    ].filter(([, value]) => value)
    return {
      ...make(
        'collocation', 'col', index, record.phrase, record.reading, record.meaning,
        `合璧术卷：核心名词「${record.noun}」与关键助词「${record.particle}」、搭配动词「${record.verb}」组成固定用法。放入修仙语境时，可把它理解为描述宗门事务、修炼状态或渡劫结果的语言法阵。${record.error ? `常见误区：${record.error}。` : ''}`,
        example, translationLines.join(' ').trim(),
        ['N2惯用搭配', '固定搭配', record.scene || '通用', '修仙语境'], 4, 'N2核心',
      ),
      sourceName: '日语N1 N2固定搭配数据库（本次仅收录N2）',
      sourceRow: Number(record.no) || undefined,
      sourceLevel: record.level,
      sourceFields: sourceFields.map(([label, value]) => ({ label, value })),
    }
  })

const wordClassGroups = [
  ['副词', ['あらかじめ', 'あえて', 'あくまで', 'いったん', 'いちおう', 'おそらく', 'かえって', 'かろうじて', 'ことごとく', 'さらに', 'せっかく', 'そもそも', 'たまたま', 'ついに', 'とりあえず', 'はたして', 'ひとまず', 'ほぼ', 'むしろ', 'わざわざ']],
  ['い形容词', ['著しい', '乏しい', '等しい', '快い', '望ましい', 'ふさわしい', '紛らわしい', '鋭い', '幅広い', '心強い', '頼もしい', 'しつこい', '鈍い', '険しい', '相応しい', '珍しい', 'まぶしい', '激しい', '慌ただしい', '好ましい']],
  ['な形容词', ['曖昧', '円滑', '健全', '柔軟', '厳密', '迅速', '適切', '妥当', '簡潔', '明確', '豊富', '深刻', '盛大', '重大', '新た', '露骨', '微妙', '独自', '有効', '慎重']],
  ['助词与接续', ['だけ', 'しか', 'こそ', 'さえ', 'ほど', 'ばかり', 'まで', 'など', 'なんて', 'なんか', 'にしては', 'として', 'において', 'に対して', 'に関して', 'をめぐって', 'にわたって', 'に基づいて', 'を通じて', 'に伴って']],
]
const wordClassEntries = wordClassGroups.flatMap(([group, terms]) => terms.map((term) => ({ group, term })))
const wordClasses = wordClassEntries.map(({ group, term }, index) => make(
  'wordClass', 'wc', index, `${group}「${term}」`, term,
  `${group}用法辨析：${term}`,
  `词类卷辨析「${term}」：确认它在句中修饰的成分、活用形式和前后接续，再判断中文功能。`,
  `「${term}」は、文の中で品詞と接続を確認して使う。`,
  `“${term}”要结合句中修饰对象、活用和接续判断。`,
  ['词类', group, '活用辨析'], 4,
))

const transitivityPairs = [
  ['開く', '開ける', '门'], ['閉まる', '閉める', '门'], ['始まる', '始める', '仪式'], ['終わる', '終える', '修行'], ['壊れる', '壊す', '法器'], ['割れる', '割る', '瓶子'], ['折れる', '折る', '树枝'], ['切れる', '切る', '绳子'], ['汚れる', '汚す', '衣服'], ['並ぶ', '並べる', '书本'],
  ['集まる', '集める', '弟子'], ['決まる', '決める', '规则'], ['変わる', '変える', '计划'], ['続く', '続ける', '修炼'], ['増える', '増やす', '灵石'], ['減る', '減らす', '负担'], ['上がる', '上げる', '温度'], ['下がる', '下げる', '价格'], ['つく', 'つける', '灯火'], ['消える', '消す', '灯火'],
  ['落ちる', '落とす', '卷轴'], ['倒れる', '倒す', '石碑'], ['立つ', '立てる', '旗帜'], ['直る', '直す', '法阵'], ['治る', '治す', '伤势'], ['戻る', '戻す', '原位'], ['動く', '動かす', '机关'], ['止まる', '止める', '机关'], ['流れる', '流す', '水'], ['濡れる', '濡らす', '衣服'],
  ['冷える', '冷やす', '茶水'], ['温まる', '温める', '汤水'], ['固まる', '固める', '泥土'], ['溶ける', '溶かす', '冰'], ['乾く', '乾かす', '衣服'], ['焼ける', '焼く', '鱼'], ['煮える', '煮る', '蔬菜'], ['沸く', '沸かす', '水'], ['冷める', '冷ます', '茶水'], ['届く', '届ける', '包裹'],
  ['入る', '入れる', '弟子'], ['出る', '出す', '弟子'], ['乗る', '乗せる', '弟子'], ['下りる', '下ろす', '弟子'], ['載る', '載せる', '文章'], ['つながる', 'つなぐ', '道路'], ['外れる', '外す', '锁扣'], ['破れる', '破る', '纸张'], ['崩れる', '崩す', '石墙'], ['詰まる', '詰める', '管道'],
  ['広がる', '広げる', '范围'], ['深まる', '深める', '理解'], ['高まる', '高める', '关心'], ['強まる', '強める', '警戒'], ['弱まる', '弱める', '影响'], ['早まる', '早める', '时间'], ['近づく', '近づける', '距离'], ['離れる', '離す', '弟子'], ['遠ざかる', '遠ざける', '危险'], ['片付く', '片付ける', '房间'],
]
const transitivity = transitivityPairs.flatMap(([auto, trans, object], pairIndex) => [
  make('transitivity', 'tr', pairIndex * 2, `${auto}（自动词）`, auto, `自动词：${object}自然发生${auto}的状态变化`, `自动词表示状态自行发生，主语用「が」，不直接对宾语施加动作。`, `${object}が${auto}。`, `${object}自然发生了变化。`, ['自动词', '动词辨析', '助词が'], 4),
  make('transitivity', 'tr', pairIndex * 2 + 1, `${trans}（他动词）`, trans, `他动词：使${object}发生${trans}的变化`, `他动词表示施事者主动改变对象，宾语用「を」，要和对应自动词成对记忆。`, `${object}を${trans}。`, `使${object}发生了变化。`, ['他动词', '动词辨析', '助词を'], 4),
])

const all = [...honorifics, ...collocations, ...wordClasses, ...transitivity]
if (sourceRows.length !== 684 || collocations.length !== 613) throw new Error(`N2 collocation counts: source=${sourceRows.length}, unique=${collocations.length}`)
if (honorifics.length !== 100 || wordClasses.length !== 80 || transitivity.length !== 120) throw new Error(`supplemental counts: ${honorifics.length}/${wordClasses.length}/${transitivity.length}`)
if (new Set(all.map((item) => item.id)).size !== all.length) throw new Error('duplicate supplemental ids')
if (new Set(all.map((item) => item.title)).size !== all.length) throw new Error('duplicate supplemental titles')

const encode = (value) => `JSON.parse(${JSON.stringify(JSON.stringify(value))}) as Knowledge[]`
const output = [
  "import type { Knowledge } from './types'",
  '',
  `export const honorifics: Knowledge[] = ${encode(honorifics)}`,
  `export const collocations: Knowledge[] = ${encode(collocations)}`,
  `export const wordClasses: Knowledge[] = ${encode(wordClasses)}`,
  `export const transitivity: Knowledge[] = ${encode(transitivity)}`,
  'export const supplementalKnowledge: Knowledge[] = [...honorifics, ...collocations, ...wordClasses, ...transitivity]',
  '',
].join('\n')

fs.writeFileSync(path.resolve(process.cwd(), 'src/supplementalKnowledge.ts'), output)
